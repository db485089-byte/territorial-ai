package com.example.territorialtacticalai

import android.graphics.Bitmap
import android.graphics.Canvas
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.roundToInt

class OcrAnalyzer {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun analyze(statsBitmap: Bitmap, leaderboardBitmap: Bitmap? = null): PlayerState {
        val merged = mergeForOcr(statsBitmap, leaderboardBitmap)
        val prepped = preprocess(merged)
        val text = recognize(prepped)
        if (!prepped.isRecycled) prepped.recycle()
        if (!merged.isRecycled) merged.recycle()

        val lines = text.lines()
            .map { it.trim().replace("|", "I") }
            .filter { it.isNotBlank() }

        val interest = parseInterest(lines)
        val percentage = parsePercentage(lines)
        val inferred = inferMe(lines)
        val me = BotSession.username?.takeIf { it.isNotBlank() } ?: SessionTracker.lockedPlayerName ?: inferred
        SessionTracker.updateName(me)

        val leaderboard = parseLeaderboard(lines, me)
        val confidence = estimateConfidence(lines, leaderboard, me, interest)

        return PlayerState(
            myName = me,
            myTroops = leaderboard.firstOrNull { it.name.equals(me, ignoreCase = true) }?.troops,
            myInterestPercent = interest,
            myTerritoryPercent = percentage,
            leaderboard = leaderboard,
            rawOcrLines = lines,
            frameTimestampMs = System.currentTimeMillis(),
            ocrConfidence = confidence
        )
    }

    private fun mergeForOcr(stats: Bitmap, leaderboard: Bitmap?): Bitmap {
        if (leaderboard == null) return stats.copy(Bitmap.Config.ARGB_8888, false)
        val w = max(stats.width, leaderboard.width)
        val gap = 12
        val h = stats.height + gap + leaderboard.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(stats, 0f, 0f, null)
        c.drawBitmap(leaderboard, 0f, (stats.height + gap).toFloat(), null)
        return out
    }

    private fun preprocess(bitmap: Bitmap): Bitmap {
        val targetW = max(420, (bitmap.width * 0.85f).toInt())
        val targetH = max(260, (bitmap.height * 0.85f).toInt())
        return Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
    }

    private suspend fun recognize(bitmap: Bitmap): String {
        val image = InputImage.fromBitmap(bitmap, 0)
        return suspendCancellableCoroutine { cont ->
            recognizer.process(image)
                .addOnSuccessListener { cont.resume(it.text) }
                .addOnFailureListener { cont.resume("") }
        }
    }

    private fun parseInterest(lines: List<String>): Double? {
        val line = lines.firstOrNull { it.contains("interest", true) }
            ?: lines.firstOrNull { Regex("""\d+(?:\.\d+)?%""").containsMatchIn(it) }
        return Regex("""(\d+(?:\.\d+)?)%""").find(line ?: "")?.groupValues?.get(1)?.toDoubleOrNull()
    }

    private fun parsePercentage(lines: List<String>): Double? {
        for (line in lines) {
            if (!line.contains("%")) continue
            if (line.contains("interest", true)) continue
            val v = Regex("""(\d+(?:\.\d+)?)%""").find(line)?.groupValues?.get(1)?.toDoubleOrNull()
            if (v != null && v in 0.0..100.0) return v
        }
        return null
    }

    private fun inferMe(lines: List<String>): String? {
        val candidate = BotSession.username?.trim()
        if (!candidate.isNullOrBlank()) return candidate
        val line = lines.firstOrNull { Regex("""^\d+[.)]?\s+.+""").containsMatchIn(it) } ?: return null
        return line
            .replace(Regex("""^\d+[.)]?\s+"""), "")
            .replace(Regex("""\s+\d[\u00A0\d,\.KkMm]*$"""), "")
            .trim()
    }

    private fun parseLeaderboard(lines: List<String>, myName: String?): List<PlayerSnapshot> {
        val result = mutableListOf<PlayerSnapshot>()
        val regex = Regex("""^(\d+)[.)]?\s+(.+?)\s+(\d[\d,\.KkMm]*)$""")
        for (line in lines) {
            val m = regex.find(line) ?: continue
            val name = m.groupValues[2].trim()
            val troops = parseCompactNumber(m.groupValues[3])
            result += PlayerSnapshot(
                name = name,
                troops = troops,
                isLikelyNeighbor = name.equals(myName, true)
            )
        }
        return result
    }

    private fun estimateConfidence(
        lines: List<String>,
        leaderboard: List<PlayerSnapshot>,
        myName: String?,
        interest: Double?
    ): Int {
        var score = 0
        if (lines.isNotEmpty()) score += 15
        if (interest != null) score += 20
        if (!myName.isNullOrBlank()) score += 20
        if (leaderboard.isNotEmpty()) score += 20
        if (leaderboard.any { it.name.equals(myName, true) && it.troops != null }) score += 25
        return score.coerceAtMost(100)
    }

    private fun parseCompactNumber(raw: String): Int? {
        val clean = raw.replace(",", "").trim()
        return when {
            clean.endsWith("k", true) -> (clean.dropLast(1).toDoubleOrNull()?.times(1_000))?.roundToInt()
            clean.endsWith("m", true) -> (clean.dropLast(1).toDoubleOrNull()?.times(1_000_000))?.roundToInt()
            else -> clean.toDoubleOrNull()?.roundToInt()
        }
    }

    fun close() {
        recognizer.close()
    }
}
