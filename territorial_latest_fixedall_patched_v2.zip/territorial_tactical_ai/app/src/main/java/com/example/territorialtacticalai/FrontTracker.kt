package com.example.territorialtacticalai

object FrontTracker {
    private var lastArea = -1
    private var lastHostile = -1
    private var dangerStreak = 0

    fun update(color: ColorAnalysisResult, mode: String): FrontAssessment {
        val area = color.playerPixels
        val hostile = color.neighborContacts.sumOf { it.contactPixels }
        val areaDelta = if (lastArea >= 0) area - lastArea else 0
        val hostileDelta = if (lastHostile >= 0) hostile - lastHostile else 0

        var dangerScore = 0
        if (hostile > 120) dangerScore += 30
        if (hostile > 220) dangerScore += 20
        if (hostileDelta > 15) dangerScore += 15
        if (areaDelta < -150) dangerScore += 20
        if (areaDelta < -350) dangerScore += 20
        if (mode.contains("Zombie", true) && hostile > 60) dangerScore += 10

        val invasion = (hostileDelta > 12 && areaDelta < 0) || dangerScore >= 55
        if (invasion) dangerStreak++ else dangerStreak = (dangerStreak - 1).coerceAtLeast(0)

        lastArea = area
        lastHostile = hostile

        return FrontAssessment(
            lockedColorHex = color.playerColorHex,
            localAreaPixels = area,
            hostileContactPixels = hostile,
            areaDelta = areaDelta,
            hostileDelta = hostileDelta,
            dangerScore = dangerScore,
            invasionDetected = dangerStreak >= 2,
            stableLock = !color.playerColorHex.isNullOrBlank()
        )
    }

    fun reset() {
        lastArea = -1
        lastHostile = -1
        dangerStreak = 0
    }
}
