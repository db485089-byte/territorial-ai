package com.example.territorialtacticalai

data class GamePresenceResult(
    val isInGame: Boolean,
    val score: Int,
    val summary: String
)

class InGameDetector {
    fun detect(rawState: PlayerState, colorState: ColorAnalysisResult, labelCount: Int): GamePresenceResult {
        var score = 0
        if (colorState.playerPixels > 3000) score += 25
        if (colorState.neighborContacts.isNotEmpty()) score += 20
        if (rawState.myInterestPercent != null) score += 20
        if (rawState.rawOcrLines.any { it.contains("interest", true) }) score += 15
        if (BotSession.calibrated) score += 10
        if (!BotSession.username.isNullOrBlank()) score += 10
        val inGame = score >= 35
        return GamePresenceResult(inGame, score, "simple")
    }
}
