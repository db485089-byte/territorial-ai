package com.example.territorialtacticalai

class StrategyEngine {
    fun advise(state: PlayerState): TacticalAdvice {
        if (!state.calibrated || !state.frontAssessment.stableLock) {
            return TacticalAdvice("RECALIBRATE", "Tap your land once so I can lock your front.", 10)
        }

        val front = state.frontAssessment
        val me = state.myTroops ?: 0
        val interest = state.myInterestPercent ?: 0.0
        val mode = state.mode

        if (mode.contains("Zombie", true)) {
            if (front.invasionDetected) {
                return TacticalAdvice("DANGER", "Your front is shrinking. Stop expanding and hold.", 90)
            }
            if (front.dangerScore >= 40) {
                return TacticalAdvice("HOLD", "Pressure is rising on your local front.", 75)
            }
            if (front.hostileContactPixels < 35 && interest > 1.0) {
                return TacticalAdvice("EXPAND", "Local front is stable. Take safe land.", 68)
            }
            if (front.hostileDelta < -10 && front.areaDelta >= 0) {
                return TacticalAdvice("PUSH", "Pressure eased. You can press forward carefully.", 66)
            }
            return TacticalAdvice("WATCH", "Stable for now. Don't overextend.", 55)
        }

        if (front.invasionDetected) {
            return TacticalAdvice("DANGER", "Border is collapsing. Hold and stop expanding.", 88)
        }
        if (state.projection?.collapseTargetName != null && me > 0) {
            return TacticalAdvice("COUNTER", "${state.projection.collapseTargetName!!.take(12)} looks weak. Punish carefully.", 72)
        }
        if (front.dangerScore >= 35) {
            return TacticalAdvice("HOLD", "Border pressure increasing. Build troops.", 70)
        }
        if (interest > 1.0 && front.hostileContactPixels < 50) {
            return TacticalAdvice("EXPAND", "Front is calm. Grow safely.", 62)
        }
        return TacticalAdvice("WATCH", "No clean move. Keep your front stable.", 50)
    }
}
