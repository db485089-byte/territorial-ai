package com.example.territorialtacticalai

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.example.territorialtacticalai.databinding.ActivityGameBinding
import kotlinx.coroutines.*

class GameActivity : AppCompatActivity() {
    private lateinit var binding: ActivityGameBinding
    private val scope = CoroutineScope(Job() + Dispatchers.Default)
    private val analyzer = OcrAnalyzer()
    private val territoryAnalyzer = ColorTerritoryAnalyzer()
    private val strategyEngine = StrategyEngine()
    private val inGameDetector = InGameDetector()

    private var loopStarted = false
    private var lastHeadline = ""
    private var lastDetail = ""
    private var scanCounter = 0

    data class CapturePack(
        val statsBitmap: Bitmap,
        val leaderboardBitmap: Bitmap,
        val mapBitmap: Bitmap,
        val sampleX: Int,
        val sampleY: Int
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.webView.settings.javaScriptEnabled = true
        binding.webView.settings.domStorageEnabled = true
        binding.webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        binding.webView.settings.loadsImagesAutomatically = true
        binding.webView.settings.mediaPlaybackRequiresUserGesture = false
        binding.webView.settings.setSupportZoom(true)
        binding.webView.webChromeClient = WebChromeClient()
        binding.webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                binding.statusText.text = "Page loaded. Join a match, then tap CALIBRATE and tap your land."
                if (!loopStarted) {
                    loopStarted = true
                    startLoop()
                }
            }
        }
        binding.webView.loadUrl("https://territorial.io")

        binding.calibrateButton.setOnClickListener {
            binding.statusText.text = "Calibration armed. Tap the middle of your land once."
            binding.touchOverlay.visibility = View.VISIBLE
        }

        binding.touchOverlay.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                BotSession.calibrationX = event.x.toInt()
                BotSession.calibrationY = event.y.toInt()
                BotSession.calibrated = true
                BotSession.lockedColorHex = null
                SessionTracker.lockedPlayerColorHex = null
                FrontTracker.reset()
                binding.touchOverlay.visibility = View.GONE
                binding.statusText.text = "Calibration saved. Waiting for a stable lock."
                true
            } else false
        }

        binding.backButton.setOnClickListener { finish() }
        binding.sessionText.text = "User: ${BotSession.username ?: "(none)"}  Mode: ${BotSession.mode}"
    }

    private fun startLoop() {
        scope.launch {
            while (isActive) {
                delay(BotSession.updateIntervalMs)
                try {
                    val pack = withContext(Dispatchers.Main) { captureRegions(binding.webView) } ?: continue
                    scanCounter++

                    val rawState = if (scanCounter % 2 == 0) {
                        analyzer.analyze(pack.statsBitmap, pack.leaderboardBitmap)
                    } else {
                        PlayerState(myName = BotSession.username, frameTimestampMs = System.currentTimeMillis(), mode = BotSession.mode)
                    }

                    val colorState = territoryAnalyzer.analyze(
                        pack.mapBitmap,
                        pack.sampleX,
                        pack.sampleY,
                        BotSession.mode
                    )
                    val front = FrontTracker.update(colorState, BotSession.mode)
                    val presence = inGameDetector.detect(rawState, colorState, 0)

                    val state = rawState.copy(
                        playerColorHex = colorState.playerColorHex,
                        playerTerritoryPixels = colorState.playerPixels,
                        neighborContacts = colorState.neighborContacts,
                        frontAssessment = front,
                        mode = BotSession.mode,
                        calibrated = BotSession.calibrated
                    )

                    val advice = when {
                        !presence.isInGame -> TacticalAdvice("WAIT MATCH", "Open a live match first.", presence.score)
                        !BotSession.calibrated -> TacticalAdvice("TAP LAND", "Tap CALIBRATE, then tap your land once.", 20)
                        else -> strategyEngine.advise(state)
                    }

                    val status = buildStatus(state, presence)
                    updateHud(advice, status)

                    pack.statsBitmap.recycle()
                    pack.leaderboardBitmap.recycle()
                    pack.mapBitmap.recycle()
                } catch (t: Throwable) {
                    updateHud(TacticalAdvice("ERROR", (t.message ?: t.javaClass.simpleName).take(60), 0), "Crash in loop")
                }
            }
        }
    }

    private suspend fun updateHud(advice: TacticalAdvice, status: String) {
        if (advice.headline == lastHeadline && advice.details == lastDetail && scanCounter % 4 != 0) return
        lastHeadline = advice.headline
        lastDetail = advice.details
        withContext(Dispatchers.Main) {
            binding.hudHeadline.text = advice.headline
            binding.hudDetail.text = advice.details
            binding.statusText.text = status
        }
    }

    private fun buildStatus(state: PlayerState, presence: GamePresenceResult): String {
        val f = state.frontAssessment
        return "Lock=${f.lockedColorHex ?: "?"} Area=${f.localAreaPixels} Hostile=${f.hostileContactPixels} ΔA=${f.areaDelta} ΔH=${f.hostileDelta} Score=${presence.score}"
    }

    private fun captureRegions(webView: WebView): CapturePack? {
        val w = webView.width
        val h = webView.height
        if (w <= 0 || h <= 0) return null

        val statsRect = Rect((w * 0.70f).toInt(), (h * 0.02f).toInt(), (w * 0.98f).toInt(), (h * 0.22f).toInt())
        val leaderboardRect = Rect((w * 0.02f).toInt(), (h * 0.08f).toInt(), (w * 0.30f).toInt(), (h * 0.42f).toInt())

        val mapRect = buildMapRect(w, h)
        val sampleX = (BotSession.calibrationX - mapRect.left).coerceIn(0, mapRect.width() - 1)
        val sampleY = (BotSession.calibrationY - mapRect.top).coerceIn(0, mapRect.height() - 1)

        return CapturePack(
            drawRegion(webView, statsRect, 360, 160),
            drawRegion(webView, leaderboardRect, 360, 300),
            drawRegion(webView, mapRect, 420, 420),
            (sampleX * 420f / mapRect.width()).toInt().coerceIn(0, 419),
            (sampleY * 420f / mapRect.height()).toInt().coerceIn(0, 419)
        )
    }

    private fun buildMapRect(w: Int, h: Int): Rect {
        if (!BotSession.calibrated || BotSession.calibrationX < 0 || BotSession.calibrationY < 0) {
            return Rect((w * 0.18f).toInt(), (h * 0.22f).toInt(), (w * 0.82f).toInt(), (h * 0.86f).toInt())
        }
        val cx = BotSession.calibrationX.coerceIn(0, w - 1)
        val cy = BotSession.calibrationY.coerceIn(0, h - 1)
        val halfW = (w * 0.18f).toInt().coerceAtLeast(140)
        val halfH = (h * 0.18f).toInt().coerceAtLeast(140)
        val left = (cx - halfW).coerceAtLeast(0)
        val top = (cy - halfH).coerceAtLeast(0)
        val right = (cx + halfW).coerceAtMost(w)
        val bottom = (cy + halfH).coerceAtMost(h)
        return Rect(left, top, right, bottom)
    }

    private fun drawRegion(webView: WebView, src: Rect, outW: Int, outH: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.scale(outW.toFloat() / src.width().toFloat(), outH.toFloat() / src.height().toFloat())
        canvas.translate(-src.left.toFloat(), -src.top.toFloat())
        canvas.clipRect(src)
        webView.draw(canvas)
        return bitmap
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        analyzer.close()
        binding.webView.destroy()
        FrontTracker.reset()
    }
}
