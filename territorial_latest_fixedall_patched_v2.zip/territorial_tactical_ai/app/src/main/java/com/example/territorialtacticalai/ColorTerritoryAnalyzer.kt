package com.example.territorialtacticalai

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

data class ColorAnalysisResult(
    val playerColorHex: String? = null,
    val playerPixels: Int = 0,
    val neighborContacts: List<NeighborContact> = emptyList()
)

class ColorTerritoryAnalyzer {

    fun analyze(
        mapBitmap: Bitmap,
        sampleX: Int,
        sampleY: Int,
        mode: String,
        preferredColorHex: String? = BotSession.lockedColorHex ?: SessionTracker.lockedPlayerColorHex
    ): ColorAnalysisResult {
        val qb = QuantizedBitmap(mapBitmap)
        val sampleHex = preferredColorHex ?: detectFromSample(qb, sampleX, sampleY, mode)
        if (sampleHex == null) return ColorAnalysisResult()

        BotSession.lockedColorHex = sampleHex
        SessionTracker.updateColor(sampleHex)

        return ColorAnalysisResult(
            playerColorHex = sampleHex,
            playerPixels = countPixels(qb, sampleHex),
            neighborContacts = detectNeighborContacts(qb, sampleHex, mode)
        )
    }

    private fun detectFromSample(qb: QuantizedBitmap, sx: Int, sy: Int, mode: String): String? {
        val counts = linkedMapOf<String, Int>()
        val x0 = (sx - 10).coerceAtLeast(0)
        val x1 = (sx + 10).coerceAtMost(qb.width - 1)
        val y0 = (sy - 10).coerceAtLeast(0)
        val y1 = (sy + 10).coerceAtMost(qb.height - 1)

        for (y in y0..y1) {
            for (x in x0..x1) {
                val hex = qb.hexAt(x, y)
                if (isIgnoredHex(hex, mode)) continue
                counts[hex] = (counts[hex] ?: 0) + 1
            }
        }
        return counts.maxByOrNull { it.value }?.key
    }

    private fun countPixels(qb: QuantizedBitmap, playerHex: String): Int {
        var count = 0
        for (y in 0 until qb.height step 2) {
            for (x in 0 until qb.width step 2) {
                if (qb.hexAt(x, y) == playerHex) count++
            }
        }
        return count * 4
    }

    private fun detectNeighborContacts(qb: QuantizedBitmap, playerHex: String, mode: String): List<NeighborContact> {
        val contacts = linkedMapOf<String, Int>()
        val dirs = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))

        for (y in 1 until qb.height - 1 step 2) {
            for (x in 1 until qb.width - 1 step 2) {
                if (qb.hexAt(x, y) != playerHex) continue
                for (d in dirs) {
                    val nHex = qb.hexAt(x + d[0], y + d[1])
                    if (nHex != playerHex && !isIgnoredHex(nHex, mode)) {
                        contacts[nHex] = (contacts[nHex] ?: 0) + 1
                    }
                }
            }
        }

        return contacts.entries.sortedByDescending { it.value }.take(4).map { NeighborContact(it.key, it.value) }
    }

    private fun isIgnoredHex(hex: String, mode: String): Boolean {
        return when {
            hex == "#000000" -> mode.contains("Zombie", true).not()
            hex == "#202020" || hex == "#404040" -> true
            mode.contains("Zombie", true) -> false
            else -> hex == "#FFFFFF"
        }
    }

    private class QuantizedBitmap(private val bitmap: Bitmap) {
        val width: Int = bitmap.width
        val height: Int = bitmap.height

        fun hexAt(x: Int, y: Int): String {
            val pixel = bitmap.getPixel(x.coerceIn(0, width - 1), y.coerceIn(0, height - 1))
            val r = quantize(Color.red(pixel))
            val g = quantize(Color.green(pixel))
            val b = quantize(Color.blue(pixel))
            return String.format("#%02X%02X%02X", r, g, b)
        }

        private fun quantize(v: Int): Int = ((v / 32) * 32).coerceIn(0, 255)
    }
}
