package com.example.territorialtacticalai

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.example.territorialtacticalai.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BotSession.resetForNewMatch()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val modes = listOf("Zombie", "Classic / BR", "Unknown")
        binding.modeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modes)

        binding.launchButton.setOnClickListener {
            BotSession.username = binding.usernameInput.text?.toString()?.trim().orEmpty().ifBlank { null }
            BotSession.mode = binding.modeSpinner.selectedItem?.toString()?.trim().orEmpty()
            startActivity(Intent(this, GameActivity::class.java))
        }

        binding.infoText.text = "This version is narrowed down to identity lock + local-front tracking. Enter your username, pick a mode, launch the game, join a match, then tap CALIBRATE and tap the middle of your land."
    }
}
