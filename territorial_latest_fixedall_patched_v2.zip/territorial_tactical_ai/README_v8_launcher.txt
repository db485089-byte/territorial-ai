v8 launcher rebuild:
- Territorial now runs inside an in-app WebView shell
- HUD is inside GameActivity instead of relying on global overlay for core use
- user enters username and mode before launch
- one-tap calibration locks your territory color
- analysis snapshots the WebView directly, no MediaProjection needed for the main path
