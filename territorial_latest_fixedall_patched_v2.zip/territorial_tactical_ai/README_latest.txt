Latest packaged build: based on v6 with speed/OCR throttling patch.
