v10 fix-all focus:
- captures both leaderboard and right-side stats instead of pretending one panel is enough
- uses manual username as identity source first
- zombie mode no longer ignores white territory
- calibration samples the actual tapped area, not the center of a later crop
- adds FrontTracker for local invasion detection using area/contact deltas
- simplifies strategy to mode-aware commands instead of debug sludge
