package com.example.territorialtacticalai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Activity
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*

class ScreenCaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA_INTENT = "data_intent"
        private const val CHANNEL_ID = "capture_channel"
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val analyzer = OcrAnalyzer()
    private val labelAnalyzer = MapLabelAnalyzer()
    private val territoryAnalyzer = ColorTerritoryAnalyzer()
    private val navalAnalyzer = NavalHeuristicAnalyzer()
    private val strategyEngine = StrategyEngine()
    private var frameCounter = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        ServiceCompat.startForeground(
            this,
            1,
            buildNotification("Watching screen"),
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA_INTENT)
        if (resultCode != Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startProjection(resultCode, data)
        return START_STICKY
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)

        val metrics = resources.displayMetrics
        imageReader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "territorial-ai-display",
            metrics.widthPixels,
            metrics.heightPixels,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            null
        )

        serviceScope.launch {
            while (isActive) {
                delay(1200)
                val bitmap = acquireBitmap() ?: continue
                val regions = FrameCropper.crop(bitmap)
                val rawState = analyzer.analyze(regions.statsPanel)
                val colorState = territoryAnalyzer.analyze(regions.mapRegion)
                val labels = if (frameCounter % 3 == 0) labelAnalyzer.detect(regions.mapRegion) else emptyList()
                frameCounter++
                val mappedContacts = NeighborMapper.mapContactsToPlayers(
                    colorState.neighborContacts,
                    labels,
                    rawState.leaderboard,
                    rawState.myName
                )
                val neighbors = mappedContacts.mapNotNull { contact ->
                    val guessed = contact.guessedName ?: return@mapNotNull null
                    val board = rawState.leaderboard.firstOrNull { it.name.equals(guessed, ignoreCase = true) }
                    PlayerSnapshot(
                        name = board?.name ?: guessed,
                        troops = board?.troops ?: contact.guessedTroops,
                        isLikelyNeighbor = true
                    )
                }
                val naval = navalAnalyzer.analyze(regions.mapRegion, colorState.playerColorHex)
                val stateWithMap = rawState.copy(
                    playerColorHex = colorState.playerColorHex,
                    playerTerritoryPixels = colorState.playerPixels,
                    neighborContacts = mappedContacts,
                    detectedLabels = labels,
                    neighbors = neighbors,
                    navalAssessment = naval
                )
                val projection = ProjectionTracker.update(stateWithMap)
                val finalState = stateWithMap.copy(projection = projection)
                OverlayService.latestAdvice = strategyEngine.advise(finalState)
                regions.statsPanel.recycle()
                regions.mapRegion.recycle()
                bitmap.recycle()
            }
        }
    }

    private fun acquireBitmap(): Bitmap? {
        val reader = imageReader ?: return null
        val image = reader.acquireLatestImage() ?: return null
        val plane = image.planes.firstOrNull() ?: run {
            image.close()
            return null
        }
        val width = image.width
        val height = image.height
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width
        val bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
        bitmap.copyPixelsFromBuffer(plane.buffer)
        image.close()
        return Bitmap.createBitmap(bitmap, 0, 0, width, height)
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        analyzer.close()
        labelAnalyzer.close()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        SessionTracker.reset()
    }

    private fun buildNotification(text: String): Notification = Notification.Builder(this, CHANNEL_ID)
        .setContentTitle("Territorial Tactical AI")
        .setContentText(text)
        .setSmallIcon(android.R.drawable.ic_media_play)
        .build()

    private fun createChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "Capture Service", NotificationManager.IMPORTANCE_LOW)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)
    }
}
