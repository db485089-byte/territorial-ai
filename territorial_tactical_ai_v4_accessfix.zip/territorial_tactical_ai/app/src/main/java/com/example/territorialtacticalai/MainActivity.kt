package com.example.territorialtacticalai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.territorialtacticalai.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var mediaProjectionManager: MediaProjectionManager
    private var pendingAutoStart: Boolean = false

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            binding.debugText.text = if (granted) {
                "Notifications granted."
            } else {
                "Notifications denied. Continuing anyway."
            }
            continueAccessFlow()
        }

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                startOverlayAndCapture(result.resultCode, data)
                binding.debugText.text = "Capture started. Open Territorial.io."
            } else {
                binding.debugText.text = "Screen capture denied. Tap Retry Capture when ready."
            }
            pendingAutoStart = false
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mediaProjectionManager = getSystemService(MediaProjectionManager::class.java)

        binding.grantAccessButton.setOnClickListener {
            pendingAutoStart = true
            continueAccessFlow()
        }

        binding.startCaptureButton.setOnClickListener {
            requestScreenCapture()
        }

        binding.stopButton.setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            stopService(Intent(this, ScreenCaptureService::class.java))
            binding.debugText.text = "Services stopped."
        }

        // Kick the flow immediately on first launch, because making the user hunt settings is stupid.
        pendingAutoStart = true
    }

    override fun onResume() {
        super.onResume()
        if (pendingAutoStart) {
            continueAccessFlow()
        }
        updateStatusText()
    }

    private fun continueAccessFlow() {
        when {
            needsNotificationPermission() -> {
                binding.debugText.text = "Requesting notification permission..."
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            !Settings.canDrawOverlays(this) -> {
                binding.debugText.text = "Opening overlay access settings..."
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
            needsBatteryOptimizationExemption() -> {
                binding.debugText.text = "Opening battery exemption screen..."
                val intent = Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
            else -> {
                requestScreenCapture()
            }
        }
    }

    private fun requestScreenCapture() {
        binding.debugText.text = "Requesting screen capture permission..."
        captureLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
    }

    private fun startOverlayAndCapture(resultCode: Int, data: Intent) {
        startService(Intent(this, OverlayService::class.java))

        val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_DATA_INTENT, data)
        }
        startForegroundService(captureIntent)
    }

    private fun needsNotificationPermission(): Boolean {
        return Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    }

    private fun needsBatteryOptimizationExemption(): Boolean {
        val pm = getSystemService(PowerManager::class.java)
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun updateStatusText() {
        val overlay = if (Settings.canDrawOverlays(this)) "yes" else "no"
        val battery = if (!needsBatteryOptimizationExemption()) "yes" else "no"
        val notifications = if (!needsNotificationPermission()) "yes" else "no"
        binding.debugText.text = "Overlay: $overlay | Notifications: $notifications | Battery exempt: $battery"
    }
}
