package com.example.territorialtacticalai

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.example.territorialtacticalai.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val modes = listOf("Classic / BR", "Zombie", "Team / Clan", "Unknown")
        binding.modeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modes)

        binding.launchButton.setOnClickListener {
            val username = binding.usernameInput.text?.toString()?.trim().orEmpty()
            val mode = binding.modeSpinner.selectedItem?.toString()?.trim().orEmpty()
            BotSession.username = username.ifBlank { null }
            BotSession.mode = mode
            startActivity(Intent(this, GameActivity::class.java))
        }

        binding.infoText.text = "This rebuild hosts Territorial inside the app. Enter your username, pick the mode, then calibrate by tapping your land once after the map loads."
    }
}
