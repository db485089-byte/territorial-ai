package com.example.territorialtacticalai

object BotSession {
    @Volatile var username: String? = null
    @Volatile var mode: String = "Unknown"
    @Volatile var calibrated: Boolean = false
    @Volatile var calibrationX: Int = -1
    @Volatile var calibrationY: Int = -1

    @Volatile var updateIntervalMs: Long = 550L
    @Volatile var statsRectLocked: Boolean = false
}
