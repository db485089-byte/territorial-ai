package com.example.territorialtacticalai

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.example.territorialtacticalai.databinding.ActivityGameBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GameActivity : AppCompatActivity() {
    private lateinit var binding: ActivityGameBinding
    private val scope = CoroutineScope(Job() + Dispatchers.Default)
    private val analyzer = OcrAnalyzer()
    private val territoryAnalyzer = ColorTerritoryAnalyzer()
    private val strategyEngine = StrategyEngine()
    private val inGameDetector = InGameDetector()
    private val navalAnalyzer = NavalHeuristicAnalyzer()

    private var latestState = PlayerState()
    private var analysisLoopStarted = false
    private var activeMode = false
    private var lastHudHeadline = "BOOTING"
    private var lastHudDetail = "Open a match"
    private var scanCounter = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.webView.settings.javaScriptEnabled = true
        binding.webView.settings.domStorageEnabled = true
        binding.webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        binding.webView.settings.loadsImagesAutomatically = true
        binding.webView.settings.mediaPlaybackRequiresUserGesture = false
        binding.webView.settings.setSupportZoom(true)
        binding.webView.webChromeClient = WebChromeClient()
        binding.webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                binding.statusText.text = "Page loaded. Tap CALIBRATE, then tap your land once."
                if (!analysisLoopStarted) {
                    analysisLoopStarted = true
                    startAnalysisLoop()
                }
            }
        }
        binding.webView.loadUrl("https://territorial.io")

        binding.calibrateButton.setOnClickListener {
            binding.statusText.text = "Calibration armed. Tap your territory once."
            binding.touchOverlay.visibility = View.VISIBLE
        }

        binding.touchOverlay.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                BotSession.calibrationX = event.x.toInt()
                BotSession.calibrationY = event.y.toInt()
                BotSession.calibrated = true
                binding.touchOverlay.visibility = View.GONE
                binding.statusText.text = "Calibration saved. Bot will lock your color from that point."
                true
            } else false
        }

        binding.backButton.setOnClickListener { finish() }
        binding.sessionText.text = "User: ${BotSession.username ?: "(none)"} | Mode: ${BotSession.mode}"
    }

    private fun startAnalysisLoop() {
        scope.launch {
            while (isActive) {
                delay(if (activeMode) BotSession.updateIntervalMs else 900L)
                try {
                    val capture = withContext(Dispatchers.Main) {
                        captureAnalysisRegions(binding.webView)
                    } ?: continue

                    scanCounter++

                    if (BotSession.calibrated) {
                        val x = capture.mapOriginX + ((capture.mapBitmap.width * 0.5f).toInt())
                        val y = capture.mapOriginY + ((capture.mapBitmap.height * 0.5f).toInt())
                        val localX = (capture.mapBitmap.width / 2).coerceIn(0, capture.mapBitmap.width - 1)
                        val localY = (capture.mapBitmap.height / 2).coerceIn(0, capture.mapBitmap.height - 1)
                        val pixel = capture.mapBitmap.getPixel(localX, localY)
                        val hex = String.format(
                            "#%02X%02X%02X",
                            Color.red(pixel),
                            Color.green(pixel),
                            Color.blue(pixel)
                        )
                        SessionTracker.updateColor(hex)
                    }

                    val rawState = analyzer.analyze(capture.statsBitmap)
                    val colorState = territoryAnalyzer.analyze(capture.mapBitmap)
                    val presence = inGameDetector.detect(rawState, colorState, 0)
                    activeMode = presence.isInGame

                    val advice = if (!presence.isInGame) {
                        TacticalAdvice("IDLE", "Waiting for a live match (${presence.score})", presence.score)
                    } else {
                        val state = rawState.copy(
                            playerColorHex = colorState.playerColorHex,
                            playerTerritoryPixels = colorState.playerPixels,
                            neighborContacts = colorState.neighborContacts,
                            navalAssessment = if (scanCounter % 4 == 0) {
                                navalAnalyzer.analyze(capture.mapBitmap, colorState.playerColorHex)
                            } else {
                                latestState.navalAssessment
                            }
                        )
                        val projection = ProjectionTracker.update(state)
                        latestState = state.copy(projection = projection)
                        strategyEngine.advise(latestState)
                    }

                    val status = buildStatus(rawState, colorState, presence, capture)
                    updateHudIfChanged(advice, status)

                    capture.statsBitmap.recycle()
                    capture.mapBitmap.recycle()
                } catch (t: Throwable) {
                    updateHudIfChanged(
                        TacticalAdvice("ERROR", (t.message ?: t.javaClass.simpleName).take(80), 0),
                        "Analysis crashed"
                    )
                }
            }
        }
    }

    private suspend fun updateHudIfChanged(advice: TacticalAdvice, status: String) {
        if (advice.headline == lastHudHeadline && advice.details == lastHudDetail) {
            if (scanCounter % 6 != 0) return
        }
        lastHudHeadline = advice.headline
        lastHudDetail = advice.details
        withContext(Dispatchers.Main) {
            binding.hudHeadline.text = advice.headline
            binding.hudDetail.text = advice.details
            binding.statusText.text = status
        }
    }

    private data class AnalysisCapture(
        val statsBitmap: Bitmap,
        val mapBitmap: Bitmap,
        val mapOriginX: Int,
        val mapOriginY: Int
    )

    private fun captureAnalysisRegions(webView: WebView): AnalysisCapture? {
        val w = webView.width
        val h = webView.height
        if (w <= 0 || h <= 0) return null

        val statsSrc = Rect(
            (w * 0.60f).toInt(),
            (h * 0.02f).toInt(),
            (w * 0.98f).toInt(),
            (h * 0.34f).toInt()
        )

        val mapRect = buildMapRect(w, h)
        val statsBitmap = drawRegion(webView, statsSrc, 420, 260)
        val mapBitmap = drawRegion(webView, mapRect, 360, 360)
        return AnalysisCapture(statsBitmap, mapBitmap, mapRect.left, mapRect.top)
    }

    private fun buildMapRect(w: Int, h: Int): Rect {
        if (!BotSession.calibrated || BotSession.calibrationX < 0 || BotSession.calibrationY < 0) {
            return Rect(
                (w * 0.20f).toInt(),
                (h * 0.22f).toInt(),
                (w * 0.80f).toInt(),
                (h * 0.82f).toInt()
            )
        }

        val cx = BotSession.calibrationX.coerceIn(0, w - 1)
        val cy = BotSession.calibrationY.coerceIn(0, h - 1)
        val halfW = (w * 0.22f).toInt().coerceAtLeast(150)
        val halfH = (h * 0.22f).toInt().coerceAtLeast(150)

        val left = (cx - halfW).coerceAtLeast(0)
        val top = (cy - halfH).coerceAtLeast(0)
        val right = (cx + halfW).coerceAtMost(w)
        val bottom = (cy + halfH).coerceAtMost(h)
        return Rect(left, top, right, bottom)
    }

    private fun drawRegion(webView: WebView, src: Rect, outW: Int, outH: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.scale(outW.toFloat() / src.width().toFloat(), outH.toFloat() / src.height().toFloat())
        canvas.translate(-src.left.toFloat(), -src.top.toFloat())
        canvas.clipRect(src)
        webView.draw(canvas)
        return bitmap
    }

    private fun buildStatus(
        raw: PlayerState,
        color: ColorAnalysisResult,
        presence: GamePresenceResult,
        capture: AnalysisCapture
    ): String {
        val name = BotSession.username ?: raw.myName ?: "?"
        return "Mode=${BotSession.mode} | User=$name | OCR=${raw.ocrConfidence} | Color=${color.playerColorHex ?: "?"} | Area=${color.playerPixels} | Score=${presence.score} | FastCapture"
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        analyzer.close()
        binding.webView.destroy()
    }
}
