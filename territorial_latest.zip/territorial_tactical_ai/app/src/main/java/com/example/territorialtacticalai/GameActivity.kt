package com.example.territorialtacticalai

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.example.territorialtacticalai.databinding.ActivityGameBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class GameActivity : AppCompatActivity() {
    private lateinit var binding: ActivityGameBinding
    private val scope = CoroutineScope(Job() + Dispatchers.Main)
    private val analyzer = OcrAnalyzer()
    private val territoryAnalyzer = ColorTerritoryAnalyzer()
    private val strategyEngine = StrategyEngine()
    private val inGameDetector = InGameDetector()
    private val navalAnalyzer = NavalHeuristicAnalyzer()
    private var latestState = PlayerState()
    private var analysisLoopStarted = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.webView.settings.javaScriptEnabled = true
        binding.webView.settings.domStorageEnabled = true
        binding.webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        binding.webView.settings.loadsImagesAutomatically = true
        binding.webView.webChromeClient = WebChromeClient()
        binding.webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                binding.statusText.text = "Page loaded. Tap CALIBRATE, then tap your land once."
                if (!analysisLoopStarted) {
                    analysisLoopStarted = true
                    startAnalysisLoop()
                }
            }
        }
        binding.webView.loadUrl("https://territorial.io")

        binding.calibrateButton.setOnClickListener {
            binding.statusText.text = "Calibration armed. Tap your territory once."
            binding.touchOverlay.visibility = View.VISIBLE
        }

        binding.touchOverlay.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                BotSession.calibrationX = event.x.toInt()
                BotSession.calibrationY = event.y.toInt()
                BotSession.calibrated = true
                binding.touchOverlay.visibility = View.GONE
                binding.statusText.text = "Calibration saved. Bot will lock your color from that point."
                true
            } else false
        }

        binding.backButton.setOnClickListener { finish() }
        binding.sessionText.text = "User: ${BotSession.username ?: "(none)"} | Mode: ${BotSession.mode}"
    }

    private fun startAnalysisLoop() {
        scope.launch {
            while (isActive) {
                delay(900)
                try {
                    val bitmap = captureWebView(binding.webView) ?: continue
                    if (BotSession.calibrated) {
                        val x = BotSession.calibrationX.coerceIn(0, bitmap.width - 1)
                        val y = BotSession.calibrationY.coerceIn(0, bitmap.height - 1)
                        val pixel = bitmap.getPixel(x, y)
                        val hex = String.format("#%02X%02X%02X", (pixel shr 16) and 0xFF, (pixel shr 8) and 0xFF, pixel and 0xFF)
                        SessionTracker.updateColor(hex)
                    }

                    val regions = FrameCropper.crop(bitmap)
                    val rawState = analyzer.analyze(regions.statsPanel)
                    val colorState = territoryAnalyzer.analyze(regions.mapRegion)
                    val presence = inGameDetector.detect(rawState, colorState, 0)
                    if (!presence.isInGame) {
                        binding.hudHeadline.text = "IDLE"
                        binding.hudDetail.text = "Waiting for a live match (${presence.score})"
                        latestState = rawState
                    } else {
                        val state = rawState.copy(
                            playerColorHex = colorState.playerColorHex,
                            playerTerritoryPixels = colorState.playerPixels,
                            neighborContacts = colorState.neighborContacts,
                            navalAssessment = navalAnalyzer.analyze(regions.mapRegion, colorState.playerColorHex)
                        )
                        val projection = ProjectionTracker.update(state)
                        latestState = state.copy(projection = projection)
                        val advice = strategyEngine.advise(latestState)
                        binding.hudHeadline.text = advice.headline
                        binding.hudDetail.text = advice.details
                    }
                    binding.statusText.text = buildStatus(rawState, colorState, presence)
                    regions.statsPanel.recycle()
                    regions.mapRegion.recycle()
                    bitmap.recycle()
                } catch (t: Throwable) {
                    binding.hudHeadline.text = "ERROR"
                    binding.hudDetail.text = (t.message ?: t.javaClass.simpleName).take(80)
                }
            }
        }
    }

    private fun captureWebView(webView: WebView): Bitmap? {
        if (webView.width <= 0 || webView.height <= 0) return null
        val bitmap = Bitmap.createBitmap(webView.width, webView.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        webView.draw(canvas)
        return bitmap
    }

    private fun buildStatus(raw: PlayerState, color: ColorAnalysisResult, presence: GamePresenceResult): String {
        val name = BotSession.username ?: raw.myName ?: "?"
        return "Mode=${BotSession.mode} | User=$name | OCR=${raw.ocrConfidence} | Color=${color.playerColorHex ?: "?"} | Area=${color.playerPixels} | Score=${presence.score}"
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        analyzer.close()
        binding.webView.destroy()
    }
}
