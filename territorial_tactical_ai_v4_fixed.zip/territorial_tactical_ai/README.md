# Territorial Tactical AI for Android

This is a starter Android project for a floating **Territorial.io tactical assistant** on mobile.

## What it already includes
- Overlay permission flow
- Screen capture flow via MediaProjection
- Tiny draggable HUD overlay
- OCR pipeline using ML Kit text recognition
- Growth projection tracker that estimates future threats and collapse windows from troop history
- Frame cropping so OCR focuses on the visible right-side panel
- Player-color lock
- Border-neighbor detection from the map region using quantized color contacts
- **Map-label OCR** that tries to map nearby border colors to actual enemy names
- **World-map naval heuristics** for coast exposure and boat pressure suggestions

## What still needs game-specific tuning
- Better matching between local map labels and leaderboard names on weird zoom levels
- Stronger world-map pathing logic for long multi-hop boat routes
- Per-device crop presets for phones with unusual aspect ratios
- Optional settings screen for sensitivity, HUD size, and refresh interval

## Main new classes
- `MapLabelAnalyzer.kt`
- `NeighborMapper.kt`
- `NavalHeuristicAnalyzer.kt`

## Notes
The bot now has enough structure to:
- read the top-right panel
- lock your player identity and territory color
- estimate border threats
- project future lobby threats
- suggest when boats are likely better than raw land aggression

This is still a prototype. Territorial.io does not expose a public live game-state feed to mobile apps, so the assistant still relies on screen capture, OCR, and heuristics instead of magical dev hooks.
