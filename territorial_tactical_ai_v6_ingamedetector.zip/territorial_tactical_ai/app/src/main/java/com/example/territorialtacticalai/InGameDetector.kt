package com.example.territorialtacticalai

data class GamePresenceResult(
    val isInGame: Boolean,
    val score: Int,
    val summary: String
)

class InGameDetector {
    private var lockedInGame = false
    private var hitStreak = 0
    private var missStreak = 0

    fun detect(
        rawState: PlayerState,
        colorState: ColorAnalysisResult,
        labelCount: Int
    ): GamePresenceResult {
        var score = 0
        val reasons = mutableListOf<String>()

        if (rawState.rawOcrLines.any { it.contains("interest", ignoreCase = true) }) {
            score += 30
            reasons += "interest"
        }
        if (rawState.myInterestPercent != null) {
            score += 20
            reasons += "interest%"
        }
        if (rawState.myTerritoryPercent != null) {
            score += 10
            reasons += "territory%"
        }
        if (rawState.leaderboard.size >= 2) {
            score += 20
            reasons += "leaderboard"
        }
        if (rawState.ocrConfidence >= 50) {
            score += 10
            reasons += "ocr"
        }
        if (colorState.playerColorHex != null) {
            score += 10
            reasons += "playerColor"
        }
        if (colorState.playerPixels > 6000) {
            score += 10
            reasons += "territoryPixels"
        }
        if (colorState.neighborContacts.isNotEmpty()) {
            score += 10
            reasons += "borders"
        }
        if (labelCount >= 1) {
            score += 5
            reasons += "labels"
        }

        val enterThreshold = 55
        val stayThreshold = 35

        if (score >= enterThreshold) {
            hitStreak++
            missStreak = 0
        } else if (score < stayThreshold) {
            missStreak++
            hitStreak = 0
        }

        if (!lockedInGame && hitStreak >= 2) {
            lockedInGame = true
        }
        if (lockedInGame && missStreak >= 3) {
            lockedInGame = false
        }

        val summary = if (reasons.isEmpty()) "no game signature" else reasons.joinToString(", ")
        return GamePresenceResult(lockedInGame, score, summary)
    }
}
