package com.example.territorialtacticalai

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class ScreenCaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA_INTENT = "data_intent"
        private const val CHANNEL_ID = "capture_channel"
        private const val TAG = "TerritorialCapture"
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val analyzer = OcrAnalyzer()
    private val labelAnalyzer = MapLabelAnalyzer()
    private val territoryAnalyzer = ColorTerritoryAnalyzer()
    private val navalAnalyzer = NavalHeuristicAnalyzer()
    private val strategyEngine = StrategyEngine()
    private val inGameDetector = InGameDetector()
    private var frameCounter = 0
    private var callbackRegistered = false

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.i(TAG, "MediaProjection stopped by system/user")
            OverlayService.latestAdvice = TacticalAdvice("CAPTURE STOPPED", "Tap Retry Capture to start again.", 0)
            cleanupProjection()
            stopSelf()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        ServiceCompat.startForeground(
            this,
            1,
            buildNotification("Watching screen"),
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA_INTENT, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA_INTENT)
        }

        if (resultCode != Activity.RESULT_OK || data == null) {
            OverlayService.latestAdvice = TacticalAdvice("NO CAPTURE", "Grant screen capture first.", 0)
            stopSelf()
            return START_NOT_STICKY
        }

        return try {
            startProjection(resultCode, data)
            START_STICKY
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to start projection", t)
            OverlayService.latestAdvice = TacticalAdvice(
                "CAPTURE ERROR",
                (t.message ?: t.javaClass.simpleName).take(60),
                0
            )
            stopSelf()
            START_NOT_STICKY
        }
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        cleanupProjection()

        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)
            ?: error("MediaProjection token was null")

        if (!callbackRegistered) {
            mediaProjection?.registerCallback(projectionCallback, Handler(Looper.getMainLooper()))
            callbackRegistered = true
        }

        val metrics = resources.displayMetrics
        imageReader = ImageReader.newInstance(
            metrics.widthPixels,
            metrics.heightPixels,
            PixelFormat.RGBA_8888,
            2
        )

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "territorial-ai-display",
            metrics.widthPixels,
            metrics.heightPixels,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            null
        ) ?: error("VirtualDisplay creation returned null")

        OverlayService.latestAdvice = TacticalAdvice("SCANNING", "Looking for Territorial.io...", 20)

        serviceScope.launch {
            while (isActive) {
                delay(1200)
                try {
                    val bitmap = acquireBitmap() ?: continue
                    val regions = FrameCropper.crop(bitmap)

                    val rawState = analyzer.analyze(regions.statsPanel)
                    val colorState = territoryAnalyzer.analyze(regions.mapRegion)
                    val labels =
                        if (frameCounter % 3 == 0) labelAnalyzer.detect(regions.mapRegion)
                        else emptyList()
                    frameCounter++

                    val presence = inGameDetector.detect(rawState, colorState, labels.size)
                    if (!presence.isInGame) {
                        OverlayService.latestAdvice = TacticalAdvice(
                            "IDLE",
                            "Not in Territorial match. Scan ${presence.score}%: ${presence.summary}.",
                            presence.score
                        )
                        regions.statsPanel.recycle()
                        regions.mapRegion.recycle()
                        bitmap.recycle()
                        continue
                    }

                    val mappedContacts = NeighborMapper.mapContactsToPlayers(
                        colorState.neighborContacts,
                        labels,
                        rawState.leaderboard,
                        rawState.myName
                    )

                    val neighbors = mappedContacts.mapNotNull { contact ->
                        val guessed = contact.guessedName ?: return@mapNotNull null
                        val board = rawState.leaderboard.firstOrNull {
                            it.name.equals(guessed, ignoreCase = true)
                        }
                        PlayerSnapshot(
                            name = board?.name ?: guessed,
                            troops = board?.troops ?: contact.guessedTroops,
                            isLikelyNeighbor = true
                        )
                    }

                    val naval = navalAnalyzer.analyze(regions.mapRegion, colorState.playerColorHex)
                    val stateWithMap = rawState.copy(
                        playerColorHex = colorState.playerColorHex,
                        playerTerritoryPixels = colorState.playerPixels,
                        neighborContacts = mappedContacts,
                        detectedLabels = labels,
                        neighbors = neighbors,
                        navalAssessment = naval
                    )
                    val projection = ProjectionTracker.update(stateWithMap)
                    val finalState = stateWithMap.copy(projection = projection)
                    OverlayService.latestAdvice = strategyEngine.advise(finalState)

                    regions.statsPanel.recycle()
                    regions.mapRegion.recycle()
                    bitmap.recycle()
                } catch (t: Throwable) {
                    Log.e(TAG, "Frame loop crashed", t)
                    OverlayService.latestAdvice = TacticalAdvice(
                        "FRAME ERROR",
                        (t.message ?: t.javaClass.simpleName).take(60),
                        0
                    )
                }
            }
        }
    }

    private fun acquireBitmap(): Bitmap? {
        val reader = imageReader ?: return null
        val image = reader.acquireLatestImage() ?: return null
        return try {
            val plane = image.planes.firstOrNull() ?: return null
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * width
            val backing = Bitmap.createBitmap(
                width + rowPadding / pixelStride,
                height,
                Bitmap.Config.ARGB_8888
            )
            backing.copyPixelsFromBuffer(plane.buffer)
            Bitmap.createBitmap(backing, 0, 0, width, height).also {
                backing.recycle()
            }
        } finally {
            image.close()
        }
    }

    private fun cleanupProjection() {
        try {
            virtualDisplay?.release()
        } catch (_: Throwable) {}
        virtualDisplay = null

        try {
            imageReader?.close()
        } catch (_: Throwable) {}
        imageReader = null

        try {
            mediaProjection?.unregisterCallback(projectionCallback)
        } catch (_: Throwable) {}
        callbackRegistered = false

        try {
            mediaProjection?.stop()
        } catch (_: Throwable) {}
        mediaProjection = null
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        analyzer.close()
        labelAnalyzer.close()
        cleanupProjection()
        SessionTracker.reset()
    }

    private fun buildNotification(text: String): Notification =
        Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Territorial Tactical AI")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()

    private fun createChannel() {
        val channel =
            NotificationChannel(CHANNEL_ID, "Capture Service", NotificationManager.IMPORTANCE_LOW)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)
    }
}
