v7 speed/ocr fix:
- OCR is throttled and cached instead of running every scan
- shorter loop in active mode, longer loop in idle mode
- OCR input is pre-cropped and scaled for better speed/consistency
- in-game detection relies more on color/border signals and less on OCR
