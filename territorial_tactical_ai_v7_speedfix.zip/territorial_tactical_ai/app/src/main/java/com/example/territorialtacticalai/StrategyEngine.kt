package com.example.territorialtacticalai

class StrategyEngine {
    fun advise(state: PlayerState): TacticalAdvice {
        val me = state.myTroops ?: 0
        val interest = state.myInterestPercent ?: 0.0
        val territory = state.myTerritoryPercent ?: 0.0
        val projection = state.projection
        val borderThreats = state.neighborContacts.size
        val ocrConfidence = state.ocrConfidence
        val naval = state.navalAssessment

        val enemies = state.leaderboard.filter { it.name != state.myName && it.troops != null }
        val weaker = enemies.filter { (it.troops ?: Int.MAX_VALUE) < me }.sortedBy { it.troops ?: Int.MAX_VALUE }
        val stronger = enemies.filter { (it.troops ?: 0) > me }.sortedByDescending { it.troops ?: 0 }
        val namedNeighbor = state.neighbors.firstOrNull()
        val highPressureNeighbor = state.neighborContacts.maxByOrNull { it.contactPixels }

        if (ocrConfidence < 35) {
            return TacticalAdvice("CALIBRATING", "Need cleaner OCR. Keep the right-side panel visible.", ocrConfidence)
        }
        if (projection?.collapseTargetName != null && weaker.any { it.name == projection.collapseTargetName }) {
            val target = weaker.first { it.name == projection.collapseTargetName }
            val send = recommendedSendPercent(me, target.troops ?: 0, aggressive = true) + 6
            return TacticalAdvice("COLLAPSE WINDOW", "${target.name.take(12)} dumped troops. Punish now with about ${send.coerceAtMost(55)}%.", 86)
        }
        if (projection?.futureThreatName != null && projection.futureThreatName != state.myName) {
            val threatNow = enemies.firstOrNull { it.name == projection.futureThreatName }
            val threatTroops = threatNow?.troops ?: projection.futureThreatPower ?: 0
            if (threatTroops > me * 0.9) {
                return TacticalAdvice("FUTURE THREAT", "${projection.futureThreatName.take(12)} is snowballing. Avoid new borders and prep boats.", 82)
            }
        }
        if (borderThreats >= 3) {
            val label = highPressureNeighbor?.guessedName ?: "multiple fronts"
            return TacticalAdvice("SURROUNDED", "Detected $borderThreats bordering colors. Biggest pressure: ${label.take(12)}. Stop expanding.", 80)
        }
        if (naval.recommendedBoatPressure && weaker.isNotEmpty()) {
            val target = namedNeighbor ?: weaker.first()
            return TacticalAdvice("NAVAL OPTION", "Ocean access is good. Consider boat pressure on ${target.name.take(12)} while keeping land defense.", 74)
        }
        if (stronger.size >= 2) {
            return TacticalAdvice("DANGER", "Multiple stronger rivals seen. Stop expanding and bank troops.", 70)
        }
        val easyNeighbor = state.neighbors
            .filter { it.troops != null && (it.troops ?: Int.MAX_VALUE) < me }
            .minByOrNull { it.troops ?: Int.MAX_VALUE }
        if (easyNeighbor != null && me > (easyNeighbor.troops ?: 0) * 1.35) {
            val send = recommendedSendPercent(me, easyNeighbor.troops ?: 0, aggressive = true)
            return TacticalAdvice("BEST BORDER HIT", "${easyNeighbor.name.take(12)} looks weak on your border. Send about $send%.", 81)
        }
        val easy = weaker.firstOrNull()
        if (easy != null && me > (easy.troops ?: 0) * 1.35) {
            val send = recommendedSendPercent(me, easy.troops ?: 0, aggressive = true)
            return TacticalAdvice("BEST TARGET: ${easy.name.take(12)}", "Attack window. Send about $send%. Border colors: $borderThreats.", 78)
        }
        if (interest < 1.5 && territory < 20.0) {
            return TacticalAdvice("EXPAND", "Interest is fading while land share is still low. Take free land or weak coast.", 68)
        }
        if (state.playerColorHex != null && state.playerTerritoryPixels != null && state.playerTerritoryPixels < 50_000) {
            return TacticalAdvice("GROW LAND", "Player color locked at ${state.playerColorHex}. Territory still modest, so expand carefully.", 66)
        }
        if (naval.hasOceanAccess && naval.exposedCoastPixels > naval.coastPixels / 3) {
            return TacticalAdvice("COAST ALERT", "Your coastline is exposed. Avoid greedy boats and keep reserve troops.", 69)
        }
        if (stronger.isNotEmpty()) {
            val threat = stronger.first()
            return TacticalAdvice("HOLD", "Top threat ${threat.name.take(12)} looks larger. Turtle and wait for a drop.", 60)
        }
        return TacticalAdvice("BUILD", "No clean kill detected. Farm interest and watch for a misfire.", 55)
    }

    private fun recommendedSendPercent(myTroops: Int, enemyTroops: Int, aggressive: Boolean): Int {
        if (enemyTroops <= 0 || myTroops <= 0) return 20
        val ratio = myTroops.toDouble() / enemyTroops.toDouble()
        val base = when {
            ratio >= 2.0 -> 45
            ratio >= 1.6 -> 38
            ratio >= 1.35 -> 30
            else -> 22
        }
        return if (aggressive) base else base - 5
    }
}
