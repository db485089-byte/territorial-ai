package com.example.territorialtacticalai

object SessionTracker {
    @Volatile var lockedPlayerName: String? = null
    @Volatile var lockedPlayerColorHex: String? = null

    fun updateName(candidate: String?) {
        if (!candidate.isNullOrBlank()) lockedPlayerName = candidate
    }

    fun updateColor(candidate: String?) {
        if (!candidate.isNullOrBlank()) lockedPlayerColorHex = candidate
    }

    fun reset() {
        lockedPlayerName = null
        lockedPlayerColorHex = null
    }
}
