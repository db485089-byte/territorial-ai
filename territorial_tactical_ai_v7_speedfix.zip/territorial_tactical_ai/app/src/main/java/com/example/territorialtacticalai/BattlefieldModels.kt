package com.example.territorialtacticalai

import android.graphics.Rect

data class NeighborContact(
    val colorHex: String,
    val contactPixels: Int,
    val guessedName: String? = null,
    val guessedTroops: Int? = null
)

data class DetectedLabel(
    val text: String,
    val troops: Int? = null,
    val colorHex: String? = null,
    val bounds: Rect? = null
)

data class NavalAssessment(
    val hasOceanAccess: Boolean = false,
    val coastPixels: Int = 0,
    val exposedCoastPixels: Int = 0,
    val recommendedBoatPressure: Boolean = false
)

data class PlayerSnapshot(
    val name: String,
    val troops: Int? = null,
    val territoryPixels: Int? = null,
    val isLikelyNeighbor: Boolean = false,
    val lastSeenMs: Long = System.currentTimeMillis()
)

data class PlayerState(
    val myName: String? = null,
    val myTroops: Int? = null,
    val myInterestPercent: Double? = null,
    val myTerritoryPercent: Double? = null,
    val leaderboard: List<PlayerSnapshot> = emptyList(),
    val neighbors: List<PlayerSnapshot> = emptyList(),
    val rawOcrLines: List<String> = emptyList(),
    val projection: ProjectionReport? = null,
    val frameTimestampMs: Long = System.currentTimeMillis(),
    val playerColorHex: String? = null,
    val playerTerritoryPixels: Int? = null,
    val neighborContacts: List<NeighborContact> = emptyList(),
    val detectedLabels: List<DetectedLabel> = emptyList(),
    val navalAssessment: NavalAssessment = NavalAssessment(),
    val ocrConfidence: Int = 0
)

data class TacticalAdvice(
    val headline: String,
    val details: String,
    val confidence: Int = 0
)
