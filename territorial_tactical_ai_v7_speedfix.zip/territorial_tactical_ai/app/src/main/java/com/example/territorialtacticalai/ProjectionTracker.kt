package com.example.territorialtacticalai

data class ProjectionReport(
    val futureThreatName: String? = null,
    val futureThreatPower: Int? = null,
    val collapseTargetName: String? = null,
    val collapseSeverity: Int = 0
)

object ProjectionTracker {
    private const val WINDOW_MS = 30_000L

    private data class Sample(
        val ts: Long,
        val troops: Int?,
        val territoryPercent: Double?
    )

    private val history = mutableMapOf<String, ArrayDeque<Sample>>()

    fun update(state: PlayerState): ProjectionReport {
        val now = state.frameTimestampMs
        val allPlayers = mutableListOf<Pair<String, Int?>>()

        state.myName?.let { allPlayers += it to state.myTroops }
        for (p in state.leaderboard) {
            allPlayers += p.name to p.troops
        }

        val myTerritory = state.myTerritoryPercent
        for ((name, troops) in allPlayers.distinctBy { it.first }) {
            val q = history.getOrPut(name) { ArrayDeque() }
            q.addLast(Sample(now, troops, if (name == state.myName) myTerritory else null))
            while (q.isNotEmpty() && now - q.first().ts > WINDOW_MS) {
                q.removeFirst()
            }
        }

        var bestThreat: String? = null
        var bestThreatPower: Int? = null
        var collapseTarget: String? = null
        var collapseSeverity = 0

        for ((name, q) in history) {
            if (q.size < 2) continue
            val first = q.first()
            val last = q.last()
            val firstTroops = first.troops ?: continue
            val lastTroops = last.troops ?: continue

            val dt = (last.ts - first.ts).coerceAtLeast(1000L) / 1000.0
            val growthPerSecond = (lastTroops - firstTroops) / dt
            val futurePower = (lastTroops + growthPerSecond * 30.0).toInt()

            if (name != state.myName) {
                if (bestThreatPower == null || futurePower > bestThreatPower!!) {
                    bestThreat = name
                    bestThreatPower = futurePower
                }

                val drop = firstTroops - lastTroops
                val dropPct = if (firstTroops > 0) ((drop.toDouble() / firstTroops.toDouble()) * 100.0).toInt() else 0
                if (dropPct > collapseSeverity && dropPct >= 22) {
                    collapseSeverity = dropPct
                    collapseTarget = name
                }
            }
        }

        return ProjectionReport(
            futureThreatName = bestThreat,
            futureThreatPower = bestThreatPower,
            collapseTargetName = collapseTarget,
            collapseSeverity = collapseSeverity
        )
    }
}
