package com.example.territorialtacticalai

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

class NavalHeuristicAnalyzer {

    fun analyze(mapBitmap: Bitmap, playerColorHex: String?): NavalAssessment {
        if (playerColorHex == null) return NavalAssessment()
        val qb = QuantizedBitmap(mapBitmap)
        var coastPixels = 0
        var exposedCoast = 0
        val dirs = arrayOf(
            intArrayOf(1, 0), intArrayOf(-1, 0),
            intArrayOf(0, 1), intArrayOf(0, -1)
        )

        for (y in 1 until qb.height - 1 step 2) {
            for (x in 1 until qb.width - 1 step 2) {
                if (qb.hexAt(x, y) != playerColorHex) continue
                var touchesWater = false
                var touchesEnemy = false
                for (d in dirs) {
                    val nx = x + d[0]
                    val ny = y + d[1]
                    if (qb.isWater(nx, ny)) touchesWater = true
                    val nHex = qb.hexAt(nx, ny)
                    if (nHex != playerColorHex && !qb.isNeutralish(nHex) && !qb.isWater(nx, ny)) touchesEnemy = true
                }
                if (touchesWater) coastPixels++
                if (touchesWater && touchesEnemy) exposedCoast++
            }
        }

        val hasOceanAccess = coastPixels > 20
        return NavalAssessment(
            hasOceanAccess = hasOceanAccess,
            coastPixels = coastPixels,
            exposedCoastPixels = exposedCoast,
            recommendedBoatPressure = hasOceanAccess && exposedCoast < coastPixels / 3 && coastPixels > 40
        )
    }

    private class QuantizedBitmap(private val bitmap: Bitmap) {
        val width = bitmap.width
        val height = bitmap.height

        fun hexAt(x: Int, y: Int): String {
            val px = bitmap.getPixel(x.coerceIn(0, width - 1), y.coerceIn(0, height - 1))
            val r = ((Color.red(px) / 32) * 32).coerceIn(0, 255)
            val g = ((Color.green(px) / 32) * 32).coerceIn(0, 255)
            val b = ((Color.blue(px) / 32) * 32).coerceIn(0, 255)
            return String.format("#%02X%02X%02X", r, g, b)
        }

        fun isWater(x: Int, y: Int): Boolean {
            val px = bitmap.getPixel(x.coerceIn(0, width - 1), y.coerceIn(0, height - 1))
            val r = Color.red(px)
            val g = Color.green(px)
            val b = Color.blue(px)
            return b > r + 18 && b > g + 18
        }

        fun isNeutralish(hex: String): Boolean {
            if (hex == "#000000" || hex == "#FFFFFF") return true
            val r = Integer.valueOf(hex.substring(1, 3), 16)
            val g = Integer.valueOf(hex.substring(3, 5), 16)
            val b = Integer.valueOf(hex.substring(5, 7), 16)
            return abs(r - g) < 10 && abs(g - b) < 10
        }
    }
}
