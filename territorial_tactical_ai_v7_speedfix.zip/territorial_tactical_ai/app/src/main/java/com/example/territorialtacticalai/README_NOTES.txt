Territorial Tactical AI Prototype Notes

What this project does:
- Requests overlay permission
- Requests MediaProjection capture permission
- Runs a small draggable overlay
- Uses ML Kit OCR on screen captures
- Parses visible leaderboard/stat text
- Produces tactical advice with a starter strategy engine

What still needs calibration:
1) Crop OCR to the right-side leaderboard/stats panel for speed and accuracy.
2) Add map-region color segmentation to detect neighboring territories touching the player's color.
3) Add attack-window detection by comparing troop drops across frames.
4) Add world-map boat detection and coastal distance penalties.

Suggested next implementation:
- Introduce a FrameCropper that only scans:
  a) top-right stats box
  b) leaderboard entries
  c) local map region around player's borders
- Persist the player's detected name for a match session.
- Add a confidence gate so low-confidence OCR doesn't spam bad orders.
