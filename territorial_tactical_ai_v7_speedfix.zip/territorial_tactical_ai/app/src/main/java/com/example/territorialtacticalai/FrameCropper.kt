package com.example.territorialtacticalai

import android.graphics.Bitmap

data class FrameRegions(
    val fullFrame: Bitmap,
    val statsPanel: Bitmap,
    val mapRegion: Bitmap
)

object FrameCropper {
    fun crop(bitmap: Bitmap): FrameRegions {
        val w = bitmap.width
        val h = bitmap.height

        val statsX = (w * 0.60).toInt().coerceAtMost(w - 1)
        val statsY = (h * 0.02).toInt().coerceAtMost(h - 1)
        val statsW = (w * 0.38).toInt().coerceAtLeast(1).coerceAtMost(w - statsX)
        val statsH = (h * 0.44).toInt().coerceAtLeast(1).coerceAtMost(h - statsY)

        val mapX = (w * 0.06).toInt().coerceAtMost(w - 1)
        val mapY = (h * 0.12).toInt().coerceAtMost(h - 1)
        val mapW = (w * 0.82).toInt().coerceAtLeast(1).coerceAtMost(w - mapX)
        val mapH = (h * 0.76).toInt().coerceAtLeast(1).coerceAtMost(h - mapY)

        return FrameRegions(
            fullFrame = bitmap,
            statsPanel = Bitmap.createBitmap(bitmap, statsX, statsY, statsW, statsH),
            mapRegion = Bitmap.createBitmap(bitmap, mapX, mapY, mapW, mapH)
        )
    }
}
