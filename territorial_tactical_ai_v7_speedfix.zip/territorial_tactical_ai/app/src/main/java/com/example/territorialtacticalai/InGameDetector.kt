package com.example.territorialtacticalai

data class GamePresenceResult(
    val isInGame: Boolean,
    val score: Int,
    val summary: String
)

class InGameDetector {
    private var lockedInGame = false
    private var hitStreak = 0
    private var missStreak = 0

    fun detect(
        rawState: PlayerState,
        colorState: ColorAnalysisResult,
        labelCount: Int
    ): GamePresenceResult {
        var score = 0
        val reasons = mutableListOf<String>()

        if (colorState.playerColorHex != null) {
            score += 24
            reasons += "playerColor"
        }
        if (colorState.playerPixels > 4500) {
            score += 18
            reasons += "territoryPixels"
        }
        if (colorState.neighborContacts.isNotEmpty()) {
            score += 16
            reasons += "borders"
        }
        if (rawState.rawOcrLines.any { it.contains("interest", ignoreCase = true) }) {
            score += 18
            reasons += "interest"
        }
        if (rawState.myInterestPercent != null) {
            score += 12
            reasons += "interest%"
        }
        if (rawState.leaderboard.size >= 2) {
            score += 12
            reasons += "leaderboard"
        }
        if (rawState.ocrConfidence >= 55) {
            score += 10
            reasons += "ocr"
        }
        if (labelCount >= 1) {
            score += 6
            reasons += "labels"
        }

        val enterThreshold = 44
        val stayThreshold = 26

        if (score >= enterThreshold) {
            hitStreak++
            missStreak = 0
        } else if (score < stayThreshold) {
            missStreak++
            hitStreak = 0
        }

        if (!lockedInGame && hitStreak >= 2) {
            lockedInGame = true
        }
        if (lockedInGame && missStreak >= 4) {
            lockedInGame = false
        }

        val summary = if (reasons.isEmpty()) "no game signature" else reasons.joinToString(", ")
        return GamePresenceResult(lockedInGame, score, summary)
    }
}
