package com.example.territorialtacticalai

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.roundToInt

class OcrAnalyzer {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun analyze(bitmap: Bitmap): PlayerState {
        val prepped = preprocess(bitmap)
        val text = recognize(prepped)
        if (prepped !== bitmap && !prepped.isRecycled) {
            prepped.recycle()
        }

        val lines = text.lines()
            .map { it.trim().replace("|", "I") }
            .filter { it.isNotBlank() }

        val interest = parseInterest(lines)
        val percentage = parsePercentage(lines)
        val inferred = inferMeFromLeaderboard(lines)
        val me = SessionTracker.lockedPlayerName ?: inferred
        SessionTracker.updateName(inferred)

        val leaderboard = parseLeaderboard(lines, me)
        val confidence = estimateConfidence(lines, leaderboard, me)

        return PlayerState(
            myName = me,
            myTroops = leaderboard.firstOrNull { it.name == me }?.troops,
            myInterestPercent = interest,
            myTerritoryPercent = percentage,
            leaderboard = leaderboard,
            neighbors = emptyList(),
            rawOcrLines = lines,
            frameTimestampMs = System.currentTimeMillis(),
            ocrConfidence = confidence
        )
    }

    private fun preprocess(bitmap: Bitmap): Bitmap {
        val cropH = (bitmap.height * 0.78f).toInt().coerceAtLeast(1)
        val cropped = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, cropH)
        val targetW = max(360, (cropped.width * 0.72f).toInt())
        val targetH = max(220, (cropped.height * 0.72f).toInt())
        return Bitmap.createScaledBitmap(cropped, targetW, targetH, true).also {
            if (cropped !== bitmap && !cropped.isRecycled) cropped.recycle()
        }
    }

    private suspend fun recognize(bitmap: Bitmap): String {
        val image = InputImage.fromBitmap(bitmap, 0)
        return suspendCancellableCoroutine { cont ->
            recognizer.process(image)
                .addOnSuccessListener { cont.resume(it.text) }
                .addOnFailureListener { cont.resume("") }
        }
    }

    private fun parseInterest(lines: List<String>): Double? {
        val line = lines.firstOrNull {
            it.contains("interest", ignoreCase = true)
        } ?: lines.firstOrNull { Regex("""\d+(?:\.\d+)?%""").containsMatchIn(it) }

        val match = Regex("""(\d+(?:\.\d+)?)%""").find(line ?: "")
        return match?.groupValues?.get(1)?.toDoubleOrNull()
    }

    private fun parsePercentage(lines: List<String>): Double? {
        val candidates = lines.filter { it.contains("%") }
        for (line in candidates) {
            if (line.contains("interest", ignoreCase = true)) continue
            val match = Regex("""(\d+(?:\.\d+)?)%""").find(line)
            val value = match?.groupValues?.get(1)?.toDoubleOrNull()
            if (value != null && value in 0.0..100.0) return value
        }
        return null
    }

    private fun inferMeFromLeaderboard(lines: List<String>): String? {
        val leaderboardLine = lines.firstOrNull {
            Regex("""^\d+[.)]?\s+.+""").containsMatchIn(it)
        } ?: return null

        return leaderboardLine
            .replace(Regex("""^\d+[.)]?\s+"""), "")
            .replace(Regex("""\s+\d[\u00A0\d,\.KkMm]*$"""), "")
            .trim()
    }

    private fun parseLeaderboard(lines: List<String>, myName: String?): List<PlayerSnapshot> {
        val result = mutableListOf<PlayerSnapshot>()
        val regex = Regex("""^(\d+)[.)]?\s+(.+?)\s+(\d[\d,\.KkMm]*)$""")

        for (line in lines) {
            val match = regex.find(line) ?: continue
            val name = match.groupValues[2].trim()
            val troops = parseCompactNumber(match.groupValues[3])
            result += PlayerSnapshot(
                name = name,
                troops = troops,
                isLikelyNeighbor = name.equals(myName, ignoreCase = true)
            )
        }
        return result
    }

    private fun estimateConfidence(
        lines: List<String>,
        leaderboard: List<PlayerSnapshot>,
        myName: String?
    ): Int {
        var score = 0
        if (lines.isNotEmpty()) score += 15
        if (lines.any { it.contains("interest", ignoreCase = true) }) score += 20
        if (leaderboard.isNotEmpty()) score += 25
        if (!myName.isNullOrBlank()) score += 20
        if (leaderboard.any { it.name.equals(myName, ignoreCase = true) && it.troops != null }) score += 20
        return score.coerceAtMost(100)
    }

    private fun parseCompactNumber(raw: String): Int? {
        val clean = raw.replace(",", "").trim()
        return when {
            clean.endsWith("k", true) -> {
                val v = clean.dropLast(1).toDoubleOrNull() ?: return null
                (v * 1_000).roundToInt()
            }
            clean.endsWith("m", true) -> {
                val v = clean.dropLast(1).toDoubleOrNull() ?: return null
                (v * 1_000_000).roundToInt()
            }
            else -> clean.toDoubleOrNull()?.roundToInt()
        }
    }

    fun close() {
        recognizer.close()
    }
}
