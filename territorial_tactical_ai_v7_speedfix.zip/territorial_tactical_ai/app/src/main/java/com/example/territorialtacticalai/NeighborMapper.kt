package com.example.territorialtacticalai

import kotlin.math.abs

object NeighborMapper {

    fun mapContactsToPlayers(
        contacts: List<NeighborContact>,
        labels: List<DetectedLabel>,
        leaderboard: List<PlayerSnapshot>,
        myName: String?
    ): List<NeighborContact> {
        val usableLabels = labels.filter { it.colorHex != null && it.text.isNotBlank() }
        return contacts.map { contact ->
            val label = usableLabels.minByOrNull { colorDistance(contact.colorHex, it.colorHex!!) }
            val guessedName = label?.text
                ?.replace(Regex("""\s+\d[\d,\.KkMm]*$"""), "")
                ?.trim()
                ?.takeIf { it.isNotBlank() && it != myName }
            val troopGuess = when {
                guessedName != null -> leaderboard.firstOrNull { it.name.equals(guessedName, ignoreCase = true) }?.troops
                else -> label?.troops
            }
            contact.copy(guessedName = guessedName, guessedTroops = troopGuess)
        }
    }

    private fun colorDistance(a: String, b: String): Int {
        fun c(s: String, i: Int) = Integer.valueOf(s.substring(i, i + 2), 16)
        val ar = c(a, 1); val ag = c(a, 3); val ab = c(a, 5)
        val br = c(b, 1); val bg = c(b, 3); val bb = c(b, 5)
        return abs(ar - br) + abs(ag - bg) + abs(ab - bb)
    }
}
