package com.example.territorialtacticalai

import android.graphics.Bitmap
import android.graphics.Color

data class ColorAnalysisResult(
    val playerColorHex: String? = null,
    val playerPixels: Int = 0,
    val neighborContacts: List<NeighborContact> = emptyList()
)

class ColorTerritoryAnalyzer {
    fun analyze(mapBitmap: Bitmap): ColorAnalysisResult {
        val quantized = QuantizedBitmap(mapBitmap)
        val locked = SessionTracker.lockedPlayerColorHex
        val playerColor = locked ?: detectPlayerColor(quantized)?.also { SessionTracker.updateColor(it) }

        if (playerColor == null) return ColorAnalysisResult()

        return ColorAnalysisResult(
            playerColorHex = playerColor,
            playerPixels = countPixels(quantized, playerColor),
            neighborContacts = detectNeighborContacts(quantized, playerColor)
        )
    }

    private fun detectPlayerColor(qb: QuantizedBitmap): String? {
        val candidates = linkedMapOf<String, Int>()
        val centerX = qb.width / 2
        val centerY = (qb.height * 0.58).toInt()
        val radiusX = (qb.width * 0.18).toInt().coerceAtLeast(20)
        val radiusY = (qb.height * 0.16).toInt().coerceAtLeast(20)

        for (y in (centerY - radiusY).coerceAtLeast(0) until (centerY + radiusY).coerceAtMost(qb.height)) {
            for (x in (centerX - radiusX).coerceAtLeast(0) until (centerX + radiusX).coerceAtMost(qb.width)) {
                val hex = qb.hexAt(x, y)
                if (isIgnoredHex(hex)) continue
                candidates[hex] = (candidates[hex] ?: 0) + 1
            }
        }
        return candidates.maxByOrNull { it.value }?.key
    }

    private fun countPixels(qb: QuantizedBitmap, playerHex: String): Int {
        var count = 0
        for (y in 0 until qb.height step 2) {
            for (x in 0 until qb.width step 2) {
                if (qb.hexAt(x, y) == playerHex) count++
            }
        }
        return count * 4
    }

    private fun detectNeighborContacts(qb: QuantizedBitmap, playerHex: String): List<NeighborContact> {
        val contacts = linkedMapOf<String, Int>()
        val dirs = arrayOf(intArrayOf(1,0), intArrayOf(-1,0), intArrayOf(0,1), intArrayOf(0,-1))

        for (y in 1 until qb.height - 1 step 2) {
            for (x in 1 until qb.width - 1 step 2) {
                if (qb.hexAt(x, y) != playerHex) continue
                for (d in dirs) {
                    val nHex = qb.hexAt(x + d[0], y + d[1])
                    if (nHex != playerHex && !isIgnoredHex(nHex)) {
                        contacts[nHex] = (contacts[nHex] ?: 0) + 1
                    }
                }
            }
        }

        return contacts.entries.sortedByDescending { it.value }.take(4).map { NeighborContact(it.key, it.value) }
    }

    private fun isIgnoredHex(hex: String): Boolean {
        return hex == "#000000" || hex == "#FFFFFF" || hex == "#202020" || hex == "#404040"
    }

    private class QuantizedBitmap(private val bitmap: Bitmap) {
        val width: Int = bitmap.width
        val height: Int = bitmap.height

        fun hexAt(x: Int, y: Int): String {
            val pixel = bitmap.getPixel(x, y)
            val r = quantize(Color.red(pixel))
            val g = quantize(Color.green(pixel))
            val b = quantize(Color.blue(pixel))
            return String.format("#%02X%02X%02X", r, g, b)
        }

        private fun quantize(v: Int): Int = ((v / 32) * 32).coerceIn(0, 255)
    }
}
