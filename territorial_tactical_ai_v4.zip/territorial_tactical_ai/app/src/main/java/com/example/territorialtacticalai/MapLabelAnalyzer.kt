package com.example.territorialtacticalai

import android.graphics.Bitmap
import android.graphics.Color
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.roundToInt

class MapLabelAnalyzer {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun detect(bitmap: Bitmap): List<DetectedLabel> {
        val image = InputImage.fromBitmap(bitmap, 0)
        val result = suspendCancellableCoroutine<com.google.mlkit.vision.text.Text> { cont ->
            recognizer.process(image)
                .addOnSuccessListener { cont.resume(it) }
                .addOnFailureListener { cont.resume(com.google.mlkit.vision.text.Text("", emptyList(), "", emptyList())) }
        }

        val labels = mutableListOf<DetectedLabel>()
        for (block in result.textBlocks) {
            val text = block.text.trim().replace("\n", " ")
            if (text.isBlank()) continue
            val bounds = block.boundingBox ?: continue
            if (bounds.width() < 16 || bounds.height() < 8) continue
            val sampledColor = sampleUnderlyingColor(bitmap, bounds)
            labels += DetectedLabel(
                text = text,
                troops = parseCompactNumber(text),
                colorHex = sampledColor,
                bounds = bounds
            )
        }
        return labels
    }

    private fun sampleUnderlyingColor(bitmap: Bitmap, bounds: android.graphics.Rect): String? {
        val left = (bounds.left - 6).coerceAtLeast(0)
        val top = (bounds.top - 6).coerceAtLeast(0)
        val right = (bounds.right + 6).coerceAtMost(bitmap.width - 1)
        val bottom = (bounds.bottom + 6).coerceAtMost(bitmap.height - 1)

        val counts = linkedMapOf<String, Int>()
        for (y in top..bottom step 2) {
            for (x in left..right step 2) {
                val p = bitmap.getPixel(x, y)
                val r = quantize(Color.red(p))
                val g = quantize(Color.green(p))
                val b = quantize(Color.blue(p))
                val hex = String.format("#%02X%02X%02X", r, g, b)
                if (hex == "#000000" || hex == "#FFFFFF" || abs(r - g) < 8 && abs(g - b) < 8) continue
                counts[hex] = (counts[hex] ?: 0) + 1
            }
        }
        return counts.maxByOrNull { it.value }?.key
    }

    private fun quantize(v: Int): Int = ((v / 32) * 32).coerceIn(0, 255)

    private fun parseCompactNumber(raw: String): Int? {
        val compact = raw.replace(",", " ").split(' ').lastOrNull()?.trim() ?: return null
        return when {
            compact.matches(Regex("""\d+(?:\.\d+)?[kKmM]""")) -> {
                val num = compact.dropLast(1).toDoubleOrNull() ?: return null
                when (compact.last().lowercaseChar()) {
                    'k' -> (num * 1_000).roundToInt()
                    'm' -> (num * 1_000_000).roundToInt()
                    else -> null
                }
            }
            compact.matches(Regex("""\d+""")) -> compact.toIntOrNull()
            else -> null
        }
    }

    fun close() {
        recognizer.close()
    }
}
