package com.example.territorialtacticalai

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.example.territorialtacticalai.databinding.ActivityGameBinding
import kotlinx.coroutines.*

class GameActivity : AppCompatActivity() {
    private lateinit var binding: ActivityGameBinding
    private val scope = CoroutineScope(Job() + Dispatchers.Default)
    private val analyzer = OcrAnalyzer()
    private val territoryAnalyzer = ColorTerritoryAnalyzer()
    private val strategyEngine = StrategyEngine()
    private val inGameDetector = InGameDetector()

    private var loopStarted = false
    private var lastHeadline = ""
    private var lastDetail = ""
    private var lastStatus = ""
    private var scanCounter = 0
    private var cachedOcrState = PlayerState()
    private var stableColorFrames = 0
    private var lastSeenColorHex: String? = null

    data class CapturePack(
        val statsBitmap: Bitmap,
        val leaderboardBitmap: Bitmap,
        val mapBitmap: Bitmap,
        val sampleX: Int,
        val sampleY: Int
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.webView.settings.javaScriptEnabled = true
        binding.webView.settings.domStorageEnabled = true
        binding.webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        binding.webView.settings.loadsImagesAutomatically = true
        binding.webView.settings.mediaPlaybackRequiresUserGesture = false
        binding.webView.settings.setSupportZoom(true)
        binding.webView.webChromeClient = WebChromeClient()
        binding.webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                binding.statusText.text = "Join a match, then tap Calibrate and tap your land."
                if (!loopStarted) {
                    loopStarted = true
                    startLoop()
                }
            }
        }
        binding.webView.loadUrl("https://territorial.io")

        binding.calibrateButton.setOnClickListener {
            binding.statusText.text = "Calibration armed. Tap the middle of your land once."
            binding.touchOverlay.visibility = View.VISIBLE
        }

        binding.touchOverlay.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                BotSession.calibrationX = event.x.toInt()
                BotSession.calibrationY = event.y.toInt()
                BotSession.calibrated = true
                BotSession.lockedColorHex = null
                BotSession.colorLockConfidence = 0
                lastSeenColorHex = null
                stableColorFrames = 0
                SessionTracker.lockedPlayerColorHex = null
                FrontTracker.reset()
                binding.touchOverlay.visibility = View.GONE
                binding.statusText.text = "Calibration saved. Hold still while I lock your color."
                true
            } else false
        }

        binding.backButton.setOnClickListener { finish() }
        binding.sessionText.text = "User: ${BotSession.username ?: "(none)"} • Mode: ${BotSession.mode}"
    }

    private fun startLoop() {
        scope.launch {
            while (isActive) {
                delay(BotSession.updateIntervalMs)
                try {
                    val pack = withContext(Dispatchers.Main) { captureRegions(binding.webView) } ?: continue
                    scanCounter++

                    if (scanCounter % 3 == 1 || cachedOcrState.myName == null) {
                        cachedOcrState = analyzer.analyze(pack.statsBitmap, pack.leaderboardBitmap)
                    }
                    val rawState = cachedOcrState.copy(
                        frameTimestampMs = System.currentTimeMillis(),
                        myName = BotSession.username ?: cachedOcrState.myName,
                        mode = BotSession.mode
                    )

                    val preferred = BotSession.lockedColorHex
                    val colorState = territoryAnalyzer.analyze(
                        pack.mapBitmap,
                        pack.sampleX,
                        pack.sampleY,
                        BotSession.mode,
                        preferred
                    )

                    if (colorState.playerColorHex != null) {
                        if (colorState.playerColorHex == lastSeenColorHex) {
                            stableColorFrames++
                        } else {
                            lastSeenColorHex = colorState.playerColorHex
                            stableColorFrames = 1
                        }
                    } else {
                        stableColorFrames = 0
                    }

                    val front = FrontTracker.update(colorState, BotSession.mode)
                    val presence = inGameDetector.detect(rawState, colorState, 0)

                    val state = rawState.copy(
                        playerColorHex = colorState.playerColorHex,
                        playerTerritoryPixels = colorState.playerPixels,
                        neighborContacts = colorState.neighborContacts,
                        frontAssessment = front,
                        mode = BotSession.mode,
                        calibrated = BotSession.calibrated
                    )

                    val advice = when {
                        !presence.isInGame -> TacticalAdvice("WAIT MATCH", "Open a live match first.", presence.score)
                        !BotSession.calibrated -> TacticalAdvice("TAP LAND", "Use Calibrate and tap your land once.", 20)
                        !front.stableLock -> TacticalAdvice("LOCKING", "Hold still. I am locking your color.", 18)
                        else -> strategyEngine.advise(state)
                    }

                    val status = buildStatus(state, presence)
                    updateHud(advice, status)

                    pack.statsBitmap.recycle()
                    pack.leaderboardBitmap.recycle()
                    pack.mapBitmap.recycle()
                } catch (t: Throwable) {
                    updateHud(
                        TacticalAdvice("ERROR", (t.message ?: t.javaClass.simpleName).take(60), 0),
                        "Runtime issue in analysis loop"
                    )
                }
            }
        }
    }

    private suspend fun updateHud(advice: TacticalAdvice, status: String) {
        val unchanged = advice.headline == lastHeadline && advice.details == lastDetail && status == lastStatus
        if (unchanged && scanCounter % 5 != 0) return

        lastHeadline = advice.headline
        lastDetail = advice.details
        lastStatus = status
        withContext(Dispatchers.Main) {
            binding.hudHeadline.text = advice.headline
            binding.hudDetail.text = advice.details
            binding.statusText.text = status
        }
    }

    private fun buildStatus(state: PlayerState, presence: GamePresenceResult): String {
        val front = state.frontAssessment
        return when {
            !BotSession.calibrated -> "Not calibrated yet."
            !front.stableLock -> "Trying to lock your color… (${front.lockScore}/3)"
            front.invasionDetected -> "Danger rising on your front."
            front.dangerScore >= 45 -> "Pressure building on your front."
            presence.isInGame -> "Color locked. Tracking local front."
            else -> "Waiting for a live match."
        }
    }

    private fun captureRegions(webView: WebView): CapturePack? {
        val w = webView.width
        val h = webView.height
        if (w <= 0 || h <= 0) return null

        val statsRect = Rect((w * 0.70f).toInt(), (h * 0.02f).toInt(), (w * 0.98f).toInt(), (h * 0.22f).toInt())
        val leaderboardRect = Rect((w * 0.02f).toInt(), (h * 0.08f).toInt(), (w * 0.30f).toInt(), (h * 0.42f).toInt())

        val mapRect = buildMapRect(w, h)
        val rawSampleX = if (BotSession.calibrated) BotSession.calibrationX else mapRect.centerX()
        val rawSampleY = if (BotSession.calibrated) BotSession.calibrationY else mapRect.centerY()
        val sampleX = (rawSampleX - mapRect.left).coerceIn(0, mapRect.width() - 1)
        val sampleY = (rawSampleY - mapRect.top).coerceIn(0, mapRect.height() - 1)

        return CapturePack(
            drawRegion(webView, statsRect, 360, 160),
            drawRegion(webView, leaderboardRect, 360, 300),
            drawRegion(webView, mapRect, 460, 460),
            (sampleX * 460f / mapRect.width()).toInt().coerceIn(0, 459),
            (sampleY * 460f / mapRect.height()).toInt().coerceIn(0, 459)
        )
    }

    private fun buildMapRect(w: Int, h: Int): Rect {
        if (!BotSession.calibrated || BotSession.calibrationX < 0 || BotSession.calibrationY < 0) {
            return Rect((w * 0.16f).toInt(), (h * 0.20f).toInt(), (w * 0.84f).toInt(), (h * 0.88f).toInt())
        }
        val cx = BotSession.calibrationX.coerceIn(0, w - 1)
        val cy = BotSession.calibrationY.coerceIn(0, h - 1)
        val halfW = (w * 0.24f).toInt().coerceAtLeast(170)
        val halfH = (h * 0.24f).toInt().coerceAtLeast(170)
        val left = (cx - halfW).coerceAtLeast(0)
        val top = (cy - halfH).coerceAtLeast(0)
        val right = (cx + halfW).coerceAtMost(w)
        val bottom = (cy + halfH).coerceAtMost(h)
        return Rect(left, top, right, bottom)
    }

    private fun drawRegion(webView: WebView, src: Rect, outW: Int, outH: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.scale(outW.toFloat() / src.width().toFloat(), outH.toFloat() / src.height().toFloat())
        canvas.translate(-src.left.toFloat(), -src.top.toFloat())
        canvas.clipRect(src)
        webView.draw(canvas)
        return bitmap
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        analyzer.close()
        binding.webView.destroy()
        FrontTracker.reset()
    }
}
