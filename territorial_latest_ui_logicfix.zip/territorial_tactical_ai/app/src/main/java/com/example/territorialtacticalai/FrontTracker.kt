package com.example.territorialtacticalai

import kotlin.math.roundToInt

object FrontTracker {
    private val areaHistory = ArrayDeque<Int>()
    private val hostileHistory = ArrayDeque<Int>()
    private var dangerStreak = 0

    fun update(color: ColorAnalysisResult, mode: String): FrontAssessment {
        val area = color.playerPixels
        val hostile = color.neighborContacts.sumOf { it.contactPixels }
        push(areaHistory, area)
        push(hostileHistory, hostile)

        val prevArea = if (areaHistory.size >= 2) areaHistory.elementAt(areaHistory.size - 2) else area
        val prevHostile = if (hostileHistory.size >= 2) hostileHistory.elementAt(hostileHistory.size - 2) else hostile
        val areaDelta = area - prevArea
        val hostileDelta = hostile - prevHostile

        val smoothArea = average(areaHistory)
        val smoothHostile = average(hostileHistory)

        updateLock(color.playerColorHex)
        val lockStable = !BotSession.lockedColorHex.isNullOrBlank() && BotSession.colorLockConfidence >= 3

        var dangerScore = 0
        if (smoothHostile > 70) dangerScore += 15
        if (smoothHostile > 130) dangerScore += 20
        if (smoothHostile > 220) dangerScore += 20
        if (hostileDelta > 10) dangerScore += 12
        if (hostileDelta > 25) dangerScore += 15
        if (areaDelta < -80) dangerScore += 15
        if (areaDelta < -180) dangerScore += 18
        if (smoothArea < 2800) dangerScore += 10
        if (mode.contains("Zombie", true) && smoothHostile > 40) dangerScore += 10

        val losingGround = areaDelta < -50 && hostileDelta > 5
        val hardPush = smoothHostile > 110 && areaDelta < 0
        val invasionNow = losingGround || hardPush || dangerScore >= 58

        if (invasionNow) dangerStreak++ else dangerStreak = (dangerStreak - 1).coerceAtLeast(0)

        val summary = when {
            !lockStable -> "Color lock unstable"
            dangerStreak >= 2 -> "Front shrinking under pressure"
            smoothHostile > 90 -> "Border pressure rising"
            smoothArea > 0 -> "Front mostly stable"
            else -> "Waiting for front data"
        }

        return FrontAssessment(
            lockedColorHex = BotSession.lockedColorHex,
            localAreaPixels = area,
            hostileContactPixels = hostile,
            smoothedAreaPixels = smoothArea,
            smoothedHostilePixels = smoothHostile,
            areaDelta = areaDelta,
            hostileDelta = hostileDelta,
            dangerScore = dangerScore.coerceAtMost(100),
            invasionDetected = dangerStreak >= 2,
            stableLock = lockStable,
            lockScore = BotSession.colorLockConfidence,
            summary = summary
        )
    }

    private fun updateLock(candidate: String?) {
        if (candidate.isNullOrBlank()) {
            BotSession.colorLockConfidence = (BotSession.colorLockConfidence - 1).coerceAtLeast(0)
            return
        }
        val current = BotSession.lockedColorHex
        when {
            current.isNullOrBlank() -> {
                BotSession.lockedColorHex = candidate
                BotSession.colorLockConfidence = 1
            }
            current == candidate -> {
                BotSession.colorLockConfidence = (BotSession.colorLockConfidence + 1).coerceAtMost(6)
            }
            BotSession.colorLockConfidence <= 1 -> {
                BotSession.lockedColorHex = candidate
                BotSession.colorLockConfidence = 1
            }
            else -> {
                BotSession.colorLockConfidence = (BotSession.colorLockConfidence - 1).coerceAtLeast(0)
            }
        }
    }

    private fun push(q: ArrayDeque<Int>, value: Int) {
        q.addLast(value)
        while (q.size > 6) q.removeFirst()
    }

    private fun average(q: ArrayDeque<Int>): Int =
        if (q.isEmpty()) 0 else (q.sum().toDouble() / q.size.toDouble()).roundToInt()

    fun reset() {
        areaHistory.clear()
        hostileHistory.clear()
        dangerStreak = 0
    }
}
