package com.example.territorialtacticalai

data class GamePresenceResult(
    val isInGame: Boolean,
    val score: Int,
    val summary: String
)

class InGameDetector {
    private var hitStreak = 0
    private var missStreak = 0
    private var locked = false

    fun detect(rawState: PlayerState, colorState: ColorAnalysisResult, labelCount: Int): GamePresenceResult {
        var score = 0
        val reasons = mutableListOf<String>()

        if (BotSession.calibrated) { score += 20; reasons += "cal" }
        if (!BotSession.username.isNullOrBlank()) { score += 10; reasons += "user" }
        if (colorState.playerPixels > 2200) { score += 18; reasons += "area" }
        if (colorState.neighborContacts.isNotEmpty()) { score += 16; reasons += "borders" }
        if (rawState.myInterestPercent != null) { score += 14; reasons += "interest" }
        if (rawState.leaderboard.isNotEmpty()) { score += 10; reasons += "board" }
        if (rawState.ocrConfidence >= 45) { score += 8; reasons += "ocr" }
        if (BotSession.mode.contains("Zombie", true)) { score += 6; reasons += "mode" }
        if (labelCount > 0) { score += 4; reasons += "labels" }

        if (score >= 40) {
            hitStreak++
            missStreak = 0
        } else if (score <= 22) {
            missStreak++
            hitStreak = 0
        }

        if (!locked && hitStreak >= 2) locked = true
        if (locked && missStreak >= 3) locked = false

        return GamePresenceResult(locked, score, reasons.joinToString(","))
    }
}
