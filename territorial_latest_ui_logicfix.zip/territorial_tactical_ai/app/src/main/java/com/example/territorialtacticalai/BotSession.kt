package com.example.territorialtacticalai

object BotSession {
    @Volatile var username: String? = null
    @Volatile var mode: String = "Unknown"
    @Volatile var calibrated: Boolean = false
    @Volatile var calibrationX: Int = -1
    @Volatile var calibrationY: Int = -1
    @Volatile var lockedColorHex: String? = null
    @Volatile var colorLockConfidence: Int = 0
    @Volatile var updateIntervalMs: Long = 450L

    fun resetForNewMatch() {
        calibrated = false
        calibrationX = -1
        calibrationY = -1
        lockedColorHex = null
        colorLockConfidence = 0
        SessionTracker.reset()
    }
}
