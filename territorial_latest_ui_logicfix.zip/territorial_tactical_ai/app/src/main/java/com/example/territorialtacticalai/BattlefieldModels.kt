package com.example.territorialtacticalai

import android.graphics.Rect

data class NeighborContact(
    val colorHex: String,
    val contactPixels: Int,
    val guessedName: String? = null,
    val guessedTroops: Int? = null
)

data class DetectedLabel(
    val text: String,
    val troops: Int? = null,
    val colorHex: String? = null,
    val bounds: Rect? = null
)

data class NavalAssessment(
    val hasOceanAccess: Boolean = false,
    val coastPixels: Int = 0,
    val exposedCoastPixels: Int = 0,
    val recommendedBoatPressure: Boolean = false
)

data class FrontAssessment(
    val lockedColorHex: String? = null,
    val localAreaPixels: Int = 0,
    val hostileContactPixels: Int = 0,
    val smoothedAreaPixels: Int = 0,
    val smoothedHostilePixels: Int = 0,
    val areaDelta: Int = 0,
    val hostileDelta: Int = 0,
    val dangerScore: Int = 0,
    val invasionDetected: Boolean = false,
    val stableLock: Boolean = false,
    val lockScore: Int = 0,
    val summary: String = ""
)

data class PlayerSnapshot(
    val name: String,
    val troops: Int? = null,
    val territoryPixels: Int? = null,
    val isLikelyNeighbor: Boolean = false,
    val lastSeenMs: Long = System.currentTimeMillis()
)

data class PlayerState(
    val myName: String? = null,
    val myTroops: Int? = null,
    val myInterestPercent: Double? = null,
    val myTerritoryPercent: Double? = null,
    val leaderboard: List<PlayerSnapshot> = emptyList(),
    val neighbors: List<PlayerSnapshot> = emptyList(),
    val rawOcrLines: List<String> = emptyList(),
    val projection: ProjectionReport? = null,
    val frameTimestampMs: Long = System.currentTimeMillis(),
    val playerColorHex: String? = null,
    val playerTerritoryPixels: Int? = null,
    val neighborContacts: List<NeighborContact> = emptyList(),
    val detectedLabels: List<DetectedLabel> = emptyList(),
    val navalAssessment: NavalAssessment = NavalAssessment(),
    val frontAssessment: FrontAssessment = FrontAssessment(),
    val ocrConfidence: Int = 0,
    val mode: String = "Unknown",
    val calibrated: Boolean = false
)

data class TacticalAdvice(
    val headline: String,
    val details: String,
    val confidence: Int = 0
)
