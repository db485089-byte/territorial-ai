package com.example.territorialtacticalai

class StrategyEngine {
    fun advise(state: PlayerState): TacticalAdvice {
        val front = state.frontAssessment
        val interest = state.myInterestPercent ?: 0.0
        val myTroops = state.myTroops ?: 0
        val zombieMode = state.mode.contains("Zombie", true)

        if (!state.calibrated) {
            return TacticalAdvice("TAP LAND", "Use Calibrate, then tap the middle of your land.", 10)
        }
        if (!front.stableLock) {
            return TacticalAdvice("LOCKING", "Hold still for a moment so I can lock your front.", 18)
        }

        if (zombieMode) {
            return zombieAdvice(front, interest, myTroops)
        }

        return classicAdvice(front, interest, myTroops, state)
    }

    private fun zombieAdvice(front: FrontAssessment, interest: Double, myTroops: Int): TacticalAdvice {
        if (front.invasionDetected || front.dangerScore >= 70) {
            return TacticalAdvice("DANGER", "You are losing ground. Stop expanding and hold.", 92)
        }
        if (front.dangerScore >= 45 || front.smoothedHostilePixels > 110) {
            return TacticalAdvice("HOLD", "Zombie pressure is building on your front.", 80)
        }
        if (front.hostileDelta < -12 && front.areaDelta >= 0) {
            return TacticalAdvice("PUSH", "Pressure eased. Press forward carefully.", 70)
        }
        if (front.smoothedHostilePixels < 40 && interest > 0.9) {
            return TacticalAdvice("EXPAND", "Your front is stable. Take safe land.", 66)
        }
        return TacticalAdvice("WATCH", "Stable for now. Don't overextend.", 52)
    }

    private fun classicAdvice(front: FrontAssessment, interest: Double, myTroops: Int, state: PlayerState): TacticalAdvice {
        if (front.invasionDetected) {
            return TacticalAdvice("DANGER", "Border is collapsing. Hold and stop expanding.", 88)
        }
        if (state.projection?.collapseTargetName != null && myTroops > 0) {
            return TacticalAdvice("COUNTER", "${state.projection.collapseTargetName!!.take(12)} looks weak. Punish carefully.", 72)
        }
        if (front.dangerScore >= 40) {
            return TacticalAdvice("HOLD", "Border pressure increasing. Build troops.", 72)
        }
        if (interest > 1.0 && front.smoothedHostilePixels < 55) {
            return TacticalAdvice("EXPAND", "Front is calm. Grow safely.", 64)
        }
        return TacticalAdvice("WATCH", "No clean move. Keep your front stable.", 50)
    }
}
